REM   Script: Proyecto final 014
REM   Proyecto final Datos

select * from Cursos;

select * from curso 
;

select * from cursos 
;

select * from CURSO;

CREATE TABLE Estudiantes ( 
  carnet INT PRIMARY KEY, 
  nombre VARCHAR(50), 
  apellido VARCHAR(50), 
  apeliido_2 VARCHAR(50), 
  sexo VARCHAR(50), 
  fecha_de_nacimiento DATE, 
  direccion VARCHAR(50), 
  telefono INT, 
  correo_electronico VARCHAR(50), 
  numero_cuenta_corriente INT, 
  ano_entrada INT 
);

CREATE TABLE CURSO ( 
  codigo_curso INT PRIMARY KEY, 
  nombre_curso VARCHAR(50), 
  descripcion VARCHAR(255), 
  creditos_teoricos INT, 
  creditos_practicos INT, 
  prerrequisitos VARCHAR(100);

CREATE TABLE CURSO ( 
  codigo_curso INT PRIMARY KEY, 
  nombre_curso VARCHAR(50), 
  descripcion VARCHAR(255), 
  creditos_teoricos INT, 
  creditos_practicos INT, 
  prerrequisitos VARCHAR(100));

CREATE TABLE Horario ( 
  id INT PRIMARY KEY, 
  curso VARCHAR(50), 
  salon VARCHAR(50), 
  edificio VARCHAR(50), 
  dias VARCHAR(50), 
  hora_inicio TIME, 
  hora_fin TIME, 
  costo DECIMAL(10,2) 
);

CREATE TABLE Horario ( 
  id INT PRIMARY KEY, 
  curso VARCHAR(50), 
  salon VARCHAR(50), 
  edificio VARCHAR(50), 
  dias VARCHAR(50), 
  hora_inicio TIME, 
  hora_fin TIME, 
  costo NUMBER(10,2) 
);

CREATE TABLE Horario ( 
  id INT PRIMARY KEY, 
  curso VARCHAR(50), 
  salon VARCHAR(50), 
  edificio VARCHAR(50), 
  dias VARCHAR(50), 
  hora_inicio VARCHAR(8), 
  hora_fin VARCHAR(8), 
  costo DECIMAL(10,2) 
);

REATE TABLE IMPARTIR_CURSO ( 


  nombre_catedratico VARCHAR(50) NOT NULL, 


  apellido_catedratico VARCHAR(50) NOT NULL, 


  seccion_curso VARCHAR(10) NOT NULL, 


  cantidad_ciclo INT NOT NULL, 


  PRIMARY KEY (nombre_catedratico, apellido_catedratico, seccion_curso) 


);


CREATE TABLE IMPARTIR_CURSO ( 
  nombre_catedratico VARCHAR(50) NOT NULL, 
  apellido_catedratico VARCHAR(50) NOT NULL, 
  seccion_curso VARCHAR(10) NOT NULL, 
  cantidad_ciclo INT NOT NULL, 
  PRIMARY KEY (nombre_catedratico, apellido_catedratico, seccion_curso) 
);

ALTER TABLE Estudiantes 
MODIFY nombre VARCHAR2(50) NOT NULL, 
MODIFY apellido VARCHAR2(50) NOT NULL, 
MODIFY apeliido_2 VARCHAR2(50) NOT NULL, 
MODIFY sexo VARCHAR2(50) NOT NULL, 
MODIFY fecha_de_nacimiento DATE NOT NULL, 
MODIFY direccion VARCHAR2(50) NOT NULL, 
MODIFY telefono INT NOT NULL, 
MODIFY correo_electronico VARCHAR2(50) NOT NULL, 
MODIFY numero_cuenta_corriente INT NOT NULL, 
MODIFY ano_entrada INT NOT NULL;

ALTER TABLE Estudiantes 
ALTER COLUMN nombre VARCHAR2(50) NOT NULL, 
ALTER COLUMN apellido VARCHAR2(50) NOT NULL, 
ALTER COLUMN apeliido_2 VARCHAR2(50) NOT NULL, 
ALTER COLUMN sexo VARCHAR2(50) NOT NULL, 
ALTER COLUMN fecha_de_nacimiento DATE NOT NULL, 
ALTER COLUMN direccion VARCHAR2(50) NOT NULL, 
ALTER COLUMN telefono INT NOT NULL, 
ALTER COLUMN correo_electronico VARCHAR2(50) NOT NULL, 
ALTER COLUMN numero_cuenta_corriente INT NOT NULL, 
ALTER COLUMN ano_entrada INT NOT NULL;

ALTER TABLE Estudiantes 
MODIFY COLUMN nombre VARCHAR2(50) NOT NULL, 
MODIFY COLUMN apellido VARCHAR2(50) NOT NULL, 
MODIFY COLUMN apeliido_2 VARCHAR2(50) NOT NULL, 
MODIFY COLUMN sexo VARCHAR2(50) NOT NULL, 
MODIFY COLUMN fecha_de_nacimiento DATE NOT NULL, 
MODIFY COLUMN direccion VARCHAR2(50) NOT NULL, 
MODIFY COLUMN telefono INT NOT NULL, 
MODIFY COLUMN correo_electronico VARCHAR2(50) NOT NULL, 
MODIFY COLUMN numero_cuenta_corriente INT NOT NULL, 
MODIFY COLUMN ano_entrada INT NOT NULL;

ALTER TABLE Estudiantes MODIFY ( 
  nombre VARCHAR2(50) NOT NULL, 
  apellido VARCHAR2(50) NOT NULL, 
  apeliido_2 VARCHAR2(50) NOT NULL, 
  sexo VARCHAR2(50) NOT NULL, 
  fecha_de_nacimiento DATE NOT NULL, 
  direccion VARCHAR2(50) NOT NULL, 
  telefono NUMBER(8) NOT NULL, 
  correo_electronico VARCHAR2(50) NOT NULL, 
  numero_cuenta_corriente INT(10) NOT NULL, 
  ano_entrada NUMBER(4) NOT NULL 
);

ALTER TABLE Estudiantes MODIFY ( 
  nombre VARCHAR2(50) NOT NULL, 
  apellido VARCHAR2(50) NOT NULL, 
  apeliido_2 VARCHAR2(50) NOT NULL, 
  sexo VARCHAR2(50) NOT NULL, 
  fecha_de_nacimiento DATE NOT NULL, 
  direccion VARCHAR2(50) NOT NULL, 
  telefono NUMBER(8) NOT NULL, 
  correo_electronico VARCHAR2(50) NOT NULL, 
  numero_cuenta_corriente INT(10) NOT NULL, 
  ano_entrada NUMBER(4) NOT NULL) 
);

ALTER TABLE Estudiantes MODIFY ( 
  nombre VARCHAR2(50) NOT NULL, 
  apellido VARCHAR2(50) NOT NULL, 
  apeliido_2 VARCHAR2(50) NOT NULL, 
  sexo VARCHAR2(50) NOT NULL, 
  fecha_de_nacimiento DATE NOT NULL, 
  direccion VARCHAR2(50) NOT NULL, 
  telefono NUMBER(8) NOT NULL, 
  correo_electronico VARCHAR2(50) NOT NULL, 
  numero_cuenta_corriente INT(10) NOT NULL, 
  ano_entrada NUMBER(4) NOT NULL 
);

ALTER TABLE Estudiantes MODIFY ( 
  nombre VARCHAR2(50) NOT NULL, 
  apellido VARCHAR2(50) NOT NULL, 
  apeliido_2 VARCHAR2(50) NOT NULL, 
  sexo VARCHAR2(50) NOT NULL, 
  fecha_de_nacimiento DATE NOT NULL, 
  direccion VARCHAR2(50) NOT NULL, 
  telefono NUMBER(8) NOT NULL, 
  correo_electronico VARCHAR2(50) NOT NULL, 
  numero_cuenta_corriente INT(10) NOT NULL, 
  ano_entrada NUMBER(4) NOT NULL);

ALTER TABLE IMPARTIR_CURSO ( 
  nombre_catedratico VARCHAR(50) NOT NULL, 
  apellido_catedratico VARCHAR(50) NOT NULL, 
  seccion_curso VARCHAR(10) NOT NULL, 
  cantidad_ciclo INT NOT NULL, 
);

CREATE TABLE Estudiantes ( 
  carnet INT PRIMARY KEY, 
  nombre VARCHAR(50) NOT NULL, 
  apellido VARCHAR(50) NOT NULL, 
  apellido_2 VARCHAR(50), 
  sexo VARCHAR(50) NOT NULL, 
  fecha_de_nacimiento DATE NOT NULL, 
  direccion VARCHAR(50), 
  telefono INT NOT NULL, 
  correo_electronico VARCHAR(50) NOT NULL, 
  numero_cuenta_corriente INT NOT NULL, 
  ano_entrada INT NOT NULL 
);

CREATE TABLE CURSO ( 
  codigo_curso INT PRIMARY KEY, 
  nombre_curso VARCHAR(50) NOT NULL, 
  descripcion VARCHAR(255) NOT NULL, 
  creditos_teoricos INT NOT NULL, 
  creditos_practicos INT NOT NULL, 
  prerrequisitos VARCHAR(100)) NOT NULL;

CREATE TABLE CURSO ( 
  codigo_curso INT PRIMARY KEY, 
  nombre_curso VARCHAR(50) NOT NULL, 
  descripcion VARCHAR(255) NOT NULL, 
  creditos_teoricos INT NOT NULL, 
  creditos_practicos INT NOT NULL, 
  prerrequisitos VARCHAR(100) NOT NULL);

CREATE TABLE Horario ( 
  id INT PRIMARY KEY, 
  curso VARCHAR(50) NOT NULL, 
  salon VARCHAR(50) NOT NULL, 
  edificio VARCHAR(50) NOT NULL, 
  dias VARCHAR(50) NOT NULL, 
  hora_inicio VARCHAR2(8) NOT NULL, 
  hora_fin VARCHAR2(8), 
  costo DECIMAL(10,2) NOT NULL 
);

CREATE TABLE IMPARTIR_CURSO ( 
  nombre_catedratico VARCHAR(50) NOT NULL, 
  apellido_catedratico VARCHAR(50) NOT NULL, 
  seccion_curso VARCHAR(10) NOT NULL, 
  cantidad_ciclo INT(10) NOT NULL, 
);

CREATE TABLE IMPARTIR_CURSO ( 
  nombre_catedratico VARCHAR(50) NOT NULL, 
  apellido_catedratico VARCHAR(50) NOT NULL, 
  seccion_curso VARCHAR(10) NOT NULL, 
  cantidad_ciclo INT NOT NULL, 
);

CREATE TABLE IMPARTIR_CURSO ( 
  nombre_catedratico VARCHAR(50) NOT NULL, 
  apellido_catedratico VARCHAR(50) NOT NULL, 
  seccion_curso VARCHAR(10) NOT NULL, 
  cantidad_ciclo INT(10) NOT NULL, 
);

CREATE TABLE IMPARTIR_CURSO ( 
  nombre_catedratico VARCHAR(50) NOT NULL, 
  apellido_catedratico VARCHAR(50) NOT NULL, 
  seccion_curso VARCHAR(10) NOT NULL, 
  cantidad_ciclo INT NOT NULL 
);

CREATE TABLE Asignacion ( 
  id INT PRIMARY KEY, 
  posible VARCHAR(50) NOT NULL, 
  estado_curso VARCHAR(50) NOT NULL, 
  nota_curso DECIMAL(5,2) NOT NULL, 
  realizacion_retiro VARCHAR(50) NOT NULL 
);

CREATE TABLE CARRERA( 
  codigo_carrera INT PRIMARY KEY, 
  nombre VARCHAR2(10) NOT NULL, 
  descripcion VARCHAR2(50) NOT NULL 
);

CREATE TABLE PENSUM ( 
  periodo_vigencia VARCHAR(50) NOT NULL, 
  fecha_inicio DATE NOT NULL, 
  fecha_fin DATE, 
);

CREATE TABLE PENSUM ( 
  periodo_vigencia VARCHAR(50) NOT NULL, 
  fecha_inicio DATE NOT NULL, 
  fecha_fin DATE 
);

INSERT INTO Estudiantes (carnet, nombre, apellido, apeliido_2, sexo, fecha_de_nacimiento, direccion, telefono, correo_electronico, numero_cuenta_corriente, ano_entrada)  
VALUES (20210030, 'Milton', 'Beltrán', 'Cordón', 'M', '18/08/2003', '1 Ave 6-24', 31007459, 'miltonbeltran@ufm.edu', 123456789, 2021);

INSERT INTO Estudiantes (carnet, nombre, apellido, apeliido_2, sexo, fecha_de_nacimiento, direccion, telefono, correo_electronico, numero_cuenta_corriente, ano_entrada)  
VALUES (20210030, 'Milton', 'Beltran', 'Cordon', 'M', '18/08/2003', '1 Ave 6-24', 31007459, 'miltonbeltran@ufm.edu', 123456789, 2021);

INSERT INTO Estudiantes (carnet, nombre, apellido, apellido_2, sexo, fecha_de_nacimiento, direccion, telefono, correo_electronico, numero_cuenta_corriente, ano_entrada)  
VALUES (20210030, 'Milton', 'Beltran', 'Cordon', 'M', '18/08/2003', '1 Ave 6-24', 31007459, 'miltonbeltran@ufm.edu', 123456789, 2021);

INSERT INTO Estudiantes (carnet, nombre, apellido, apellido_2, sexo, fecha_de_nacimiento, direccion, telefono, correo_electronico, numero_cuenta_corriente, ano_entrada)  
VALUES (20210030, 'Milton', 'Beltran', 'Cordon', 'M', '08/18/2003', '1 Ave 6-24', 31007459, 'miltonbeltran@ufm.edu', 123456789, 2021);

INSERT INTO Estudiantes (carnet, nombre, apellido, apellido_2, sexo, fecha_de_nacimiento, direccion, telefono, correo_electronico, numero_cuenta_corriente, ano_entrada)  
VALUES (20210030, 'Milton', 'Beltran', 'Cordon', 'M', '08/18/2003' 'MM-DD-YYYY', '1 Ave 6-24', 31007459, 'miltonbeltran@ufm.edu', 123456789, 2021);

INSERT INTO Estudiantes (carnet, nombre, apellido, apellido_2, sexo, fecha_de_nacimiento, direccion, telefono, correo_electronico, numero_cuenta_corriente, ano_entrada)  
VALUES (20210030, 'Milton', 'Beltran', 'Cordon', 'M', '08/18/2003 MM-DD-YYYY', '1 Ave 6-24', 31007459, 'miltonbeltran@ufm.edu', 123456789, 2021);

INSERT INTO Estudiantes (carnet, nombre, apellido, apellido_2, sexo, fecha_de_nacimiento, direccion, telefono, correo_electronico, numero_cuenta_corriente, ano_entrada)  
VALUES (20210030, 'Milton', 'Beltran', 'Cordon', 'M', '08-18-2003' , '1 Ave 6-24', 31007459, 'miltonbeltran@ufm.edu', 123456789, 2021);

INSERT INTO Estudiantes (carnet, nombre, apellido, apellido_2, sexo, fecha_de_nacimiento, direccion, telefono, correo_electronico, numero_cuenta_corriente, ano_entrada)  
VALUES (20210030, 'Milton', 'Beltran', 'Cordon', 'M', '18-08-2003' , '1 Ave 6-24', 31007459, 'miltonbeltran@ufm.edu', 123456789, 2021);

INSERT INTO Estudiantes (carnet, nombre, apellido, apellido_2, sexo, fecha_de_nacimiento, direccion, telefono, correo_electronico, numero_cuenta_corriente, ano_entrada)  
VALUES (20210030, 'Milton', 'Beltran', 'Cordon', 'M', '08-18-2003 DD-MM-YYYY' , '1 Ave 6-24', 31007459, 'miltonbeltran@ufm.edu', 123456789, 2021);

INSERT INTO Estudiantes (carnet, nombre, apellido, apellido_2, sexo, fecha_de_nacimiento, direccion, telefono, correo_electronico, numero_cuenta_corriente, ano_entrada)  
VALUES (20210030, 'Milton', 'Beltran', 'Cordon', 'M', '18-08-2003' , '1 Ave 6-24', 31007459, 'miltonbeltran@ufm.edu', 123456789, 2021);

SELECT * FROM Estudiantes;

INSERT INTO Estudiantes (carnet, nombre, apellido, apellido_2, sexo, fecha_de_nacimiento, direccion, telefono, correo_electronico, numero_cuenta_corriente, ano_entrada)  
VALUES (20210030, 'Milton', 'Beltran', 'Cordon', 'M', '2003-08-18' , '1 Ave 6-24', 31007459, 'miltonbeltran@ufm.edu', 123456789, 2021);

INSERT INTO Estudiantes (carnet, nombre, apellido, apellido_2, sexo, fecha_de_nacimiento, direccion, telefono, correo_electronico, numero_cuenta_corriente, ano_entrada)  
VALUES (20210030, 'Milton', 'Beltran', 'Cordon', 'M', to_date('2003-08-18', 'yyyy-mm-dd') , '1 Ave 6-24', 31007459, 'miltonbeltran@ufm.edu', 123456789, 2021);

SELECT * FROM Estudiantes;

INSERT INTO Estudiantes (carnet, nombre, apellido, apellido_2, sexo, fecha_de_nacimiento, direccion, telefono, correo_electronico, numero_cuenta_corriente, ano_entrada)  
VALUES (20210003, 'Javier', 'Caniz', 'Meng', 'M', to_date('2002-02-21', 'yyyy-mm-dd') , 'condominio monte vista club', 59494970, 'javiercaniz@ufm.edu', 987654321, 2020);

SELECT * FROM Estudiantes;

INSERT INTO Estudiantes (carnet, nombre, apellido, apellido_2, sexo, fecha_de_nacimiento, direccion, telefono, correo_electronico, numero_cuenta_corriente, ano_entrada)  
VALUES (20210104, 'Keneth', 'Ruiz', 'Martinez', 'M', to_date('2002-02-05', 'yyyy-mm-dd') , '20 avenida zona 15', 30514244, 'kgruiz@ufm.edu', 568439753, 2020);

SELECT * FROM Estudiantes;

INSERT INTO Cursos (codigo_curso, nombre_curso, descripcion, creditos_teoricos, creditos_practicos, prerrequisitos)  
VALUES (001, 'Ecuaciones diferenciales', 'Curso matematico de ecuaciones diferenciales', 3,3, 'Algebra Lineal, Calculo Integral');

INSERT INTO Curso (codigo_curso, nombre_curso, descripcion, creditos_teoricos, creditos_practicos, prerrequisitos)  
VALUES (001, 'Ecuaciones diferenciales', 'Curso matematico de ecuaciones diferenciales', 3,3, 'Algebra Lineal, Calculo Integral');

SELECT * FROM Curso;

SELECT * FROM Curso;

INSERT INTO Curso (codigo_curso, nombre_curso, descripcion, creditos_teoricos, creditos_practicos, prerrequisitos)  
VALUES (002, 'Filosofia de Hayek', 'Filo y vision de Frederick Hayek', 3,3, 'Economia 2, Economia 1');

SELECT * FROM Curso;

INSERT INTO Curso (codigo_curso, nombre_curso, descripcion, creditos_teoricos, creditos_practicos, prerrequisitos)  
VALUES (003, 'Econometria 1', 'Curso de analisis econometrico', 3,3, 'Statistical Thinking 1 y 2');

SELECT * FROM Curso;

INSERT INTO Curso (codigo_curso, nombre_curso, descripcion, creditos_teoricos, creditos_practicos, prerrequisitos)  
VALUES (004, 'Seminario de Economia 1', 'Analisis macroeconomico de Guatemala', 0.75,0.75, 'Teorias monetarias, Microeconomia');

SELECT * FROM Curso;

INSERT INTO Curso (codigo_curso, nombre_curso, descripcion, creditos_teoricos, creditos_practicos, prerrequisitos)  
VALUES (005, 'Arquitectura del Computador', 'Estudio componentes computacionales', 3,3, 'Estructura de Datos y programacion orientada a objetos');

SELECT * FROM Curso;

INSERT INTO Curso (codigo_curso, nombre_curso, descripcion, creditos_teoricos, creditos_practicos, prerrequisitos)  
VALUES (006, 'Programacion Lineal', 'Utilizacion de algebra lineal orientado a programacion', 3,3, 'Algebra Lineal, Calculo integral');

SELECT * FROM Curso;

INSERT INTO Curso (codigo_curso, nombre_curso, descripcion, creditos_teoricos, creditos_practicos, prerrequisitos)  
VALUES (007, 'Datos 1', 'Utilizacion de SQL', 3,3, 'Estructura de datos y programacion orientada a objetos');

SELECT * FROM Curso;

SELECT * FROM CURSO;

INSERT INTO HORARIO (id, curso, salon, edificio, dias, hora_inicio, hora_fin, costo) 
VALUES (0001, 'Arquitectura del Computador' , 'EN-606', 'Escuela de Negocios', 'Martes y Jueves', '17:30', '18:50', 9000) 
INSERT INTO HORARIO (id, curso, salon, edificio, dias, hora_inicio, hora_fin, costo) 
VALUES (0002, 'Datos I' , 'A-311', 'Edificio Academico', 'Martes y Jueves', '19:00', '20:20', 9000) 
INSERT INTO HORARIO (id, curso, salon, edificio, dias, hora_inicio, hora_fin, costo) 
VALUES (0003, 'Libertad en Accion' , 'E-513', 'Edificio Academico', 'Lunes y Miercoles', '14:30', '15:50', 4500) 
INSERT INTO HORARIO (id, curso, salon, edificio, dias, hora_inicio, hora_fin, costo) 
VALUES (0004, 'Econometria' , 'D-409', 'Edificio Academico', 'Lunes y Miercoles', '07:00', '08:20', 9000) 
INSERT INTO HORARIO (id, curso, salon, edificio, dias, hora_inicio, hora_fin, costo) 
VALUES (0005, 'Administracion Financiera II' , 'D-507', 'Edificio Academico', 'Martes y Jueves', '10:00', '11:20', 9000) 
INSERT INTO HORARIO (id, curso, salon, edificio, dias, hora_inicio, hora_fin, costo) 
VALUES (0006, 'Filosofia de Hayek' , 'A-411', 'Edificio Academico', 'Lunes y Miercoles', '08:30', '09:50', 9000) 
INSERT INTO HORARIO (id, curso, salon, edificio, dias, hora_inicio, hora_fin, costo) 
VALUES (0007, 'Data Science' , 'D-505', 'Edificio Academico', 'Lunes y Viernes', '13:00', '14:20', 9000) 
INSERT INTO HORARIO (id, curso, salon, edificio, dias, hora_inicio, hora_fin, costo) 
VALUES (0008, 'Seminario de Economia' , 'E-513', 'Edificio Academico', 'Viernes', '10:00', '11:20', 4500) 
INSERT INTO HORARIO (id, curso, salon, edificio, dias, hora_inicio, hora_fin, costo) 
VALUES (0009, 'Programacion Lineal' , 'D-504', 'Edificio Academico', 'Lunes y Miercoles', '16:00', '17:20', 9000);

INSERT INTO HORARIO (id, curso, salon, edificio, dias, hora_inicio, hora_fin, costo) 
VALUES (0007, 'Data Science' , 'D-505', 'Edificio Academico', 'Lunes y Viernes', '13:00', '14:20', 9000) 
INSERT INTO HORARIO (id, curso, salon, edificio, dias, hora_inicio, hora_fin, costo) 
VALUES (0008, 'Seminario de Economia' , 'E-513', 'Edificio Academico', 'Viernes', '10:00', '11:20', 4500) 
INSERT INTO HORARIO (id, curso, salon, edificio, dias, hora_inicio, hora_fin, costo) 
VALUES (0009, 'Programacion Lineal' , 'D-504', 'Edificio Academico', 'Lunes y Miercoles', '16:00', '17:20', 9000);

INSERT INTO HORARIO (id, curso, salon, edificio, dias, hora_inicio, hora_fin, costo) 
VALUES (0002, 'Datos I' , 'A-311', 'Edificio Academico', 'Martes y Jueves', '19:00', '20:20', 9000);

INSERT INTO HORARIO (id, curso, salon, edificio, dias, hora_inicio, hora_fin, costo) 
VALUES (0001, 'Arquitectura del Computador' , 'EN-606', 'Escuela de Negocios', 'Martes y Jueves', '17:30', '18:50', 9000);

INSERT INTO HORARIO (id, curso, salon, edificio, dias, hora_inicio, hora_fin, costo) 
VALUES (0003, 'Libertad en Accion' , 'E-513', 'Edificio Academico', 'Lunes y Miercoles', '14:30', '15:50', 4500);

INSERT INTO HORARIO (id, curso, salon, edificio, dias, hora_inicio, hora_fin, costo) 
VALUES (0004, 'Econometria' , 'D-409', 'Edificio Academico', 'Lunes y Miercoles', '07:00', '08:20', 9000);

INSERT INTO HORARIO (id, curso, salon, edificio, dias, hora_inicio, hora_fin, costo) 
VALUES (0005, 'Administracion Financiera II' , 'D-507', 'Edificio Academico', 'Martes y Jueves', '10:00', '11:20', 9000);

INSERT INTO HORARIO (id, curso, salon, edificio, dias, hora_inicio, hora_fin, costo) 
VALUES (0006, 'Filosofia de Hayek' , 'A-411', 'Edificio Academico', 'Lunes y Miercoles', '08:30', '09:50', 9000);

INSERT INTO HORARIO (id, curso, salon, edificio, dias, hora_inicio, hora_fin, costo) 
VALUES (0007, 'Data Science' , 'D-505', 'Edificio Academico', 'Lunes y Viernes', '13:00', '14:20', 9000);

INSERT INTO HORARIO (id, curso, salon, edificio, dias, hora_inicio, hora_fin, costo) 
VALUES (0008, 'Seminario de Economia' , 'E-513', 'Edificio Academico', 'Viernes', '10:00', '11:20', 4500);

INSERT INTO HORARIO (id, curso, salon, edificio, dias, hora_inicio, hora_fin, costo) 
VALUES (0009, 'Programacion Lineal' , 'D-504', 'Edificio Academico', 'Lunes y Miercoles', '16:00', '17:20', 9000);

INSERT INTO Curso (codigo_curso, nombre_curso, descripcion, creditos_teoricos, creditos_practicos, prerrequisitos)  
VALUES (028, 'Public Choice', 'Curso donde se aprende sobre politica nacional', 1.5,1.5, 'Economia 2');

INSERT INTO Curso (codigo_curso, nombre_curso, descripcion, creditos_teoricos, creditos_practicos, prerrequisitos)  
VALUES (029, 'Elements of Machine Learning', 'Curso donde se aprende sobre el entrenamineto de software automatizado', 3,3, 'N/A');

INSERT INTO Curso (codigo_curso, nombre_curso, descripcion, creditos_teoricos, creditos_practicos, prerrequisitos)  
VALUES (030, 'Machine Learning Model', 'Curso donde se aprende sobre modelo del software que aprende', 3,3, 'N/A');

INSERT INTO Curso (codigo_curso, nombre_curso, descripcion, creditos_teoricos, creditos_practicos, prerrequisitos)  
VALUES (031, 'Administracion Financiera 2', 'Analisis financiero avanzado', 3,3, 'Administracion Financiera 1');

INSERT INTO Curso (codigo_curso, nombre_curso, descripcion, creditos_teoricos, creditos_practicos, prerrequisitos)  
VALUES (032, 'Big Data', 'Aplicaciones informaticas para procesar datos a gran escala', 3,3, 'N/A');

INSERT INTO Curso (codigo_curso, nombre_curso, descripcion, creditos_teoricos, creditos_practicos, prerrequisitos)  
VALUES (033, 'Business Intelligence', 'Mejora la toma de decisiones empresariales basadas en dattos', 3 , 3 , 'N/A');

INSERT INTO Curso (codigo_curso, nombre_curso, descripcion, creditos_teoricos, creditos_practicos, prerrequisitos)  
VALUES (034, 'Introduccion a Redes', 'Curso para aprender sobre el manejo de redes', 3,3, 'Arquitectura del Computador');

INSERT INTO Curso (codigo_curso, nombre_curso, descripcion, creditos_teoricos, creditos_practicos, prerrequisitos)  
VALUES (035, 'Sistemas Operativos', 'Desarrollo de sistemas operativos para computador', 3,3, 'Compiladores');

INSERT INTO Curso (codigo_curso, nombre_curso, descripcion, creditos_teoricos, creditos_practicos, prerrequisitos)  
VALUES (018, 'Economia Austriaca 1', 'curso interdisciplinario acerca de economia austriaca y como es la filosofia', 3,3, 'Microeconomia');

INSERT INTO Curso (codigo_curso, nombre_curso, descripcion, creditos_teoricos, creditos_practicos, prerrequisitos)  
VALUES (019, 'Filosofia de Mises', 'curso interdisciplinario acerca de la vida y cosmovision de mises', 3,3, 'Economia 2');

INSERT INTO Curso (codigo_curso, nombre_curso, descripcion, creditos_teoricos, creditos_practicos, prerrequisitos)  
VALUES (020, 'Pensamiento Politico Contemporaneo', 'curso acerca del la cosmovision post-moderna', 3,3, 'Etica de la Libertad');

INSERT INTO Curso (codigo_curso, nombre_curso, descripcion, creditos_teoricos, creditos_practicos, prerrequisitos)  
VALUES (021, 'Ingieneria de Software', 'curso acerca de sistemas y su integracion en el campo de la mecatronica', 3,3, 'Arquitectura del Computador');

INSERT INTO Curso (codigo_curso, nombre_curso, descripcion, creditos_teoricos, creditos_practicos, prerrequisitos)  
VALUES (022, 'Compiladores', 'curso acerca de la composicion de los compiladores', 3,3, 'Arquitectura del computador');

INSERT INTO Curso (codigo_curso, nombre_curso, descripcion, creditos_teoricos, creditos_practicos, prerrequisitos)  
VALUES (023, 'Datos 2', 'curso acerca de almacenaje,manejo y modelado de datos avanzado', 3,3, 'Datos 1');

INSERT INTO Curso (codigo_curso, nombre_curso, descripcion, creditos_teoricos, creditos_practicos, prerrequisitos)  
VALUES (024, 'Data Product', 'curso acerca de la data de un producto', 3,3, 'N/A');

INSERT INTO Curso (codigo_curso, nombre_curso, descripcion, creditos_teoricos, creditos_practicos, prerrequisitos)  
VALUES (025, 'Data Wrangling', 'curso acerca de  reunir datos de una variedad de fuentes de datos que pueden estar incompletos, complejos o desordenados, y limpiarlos ', 3,3, 'N/A');

INSERT INTO Curso (codigo_curso, nombre_curso, descripcion, creditos_teoricos, creditos_practicos, prerrequisitos)  
VALUES (025, 'Libertad en Accion 2', 'curso interdisciplinario con otroas facultades con el fin de resolver un problema', 3,3, 'Economia 2');

INSERT INTO Curso (codigo_curso, nombre_curso, descripcion, creditos_teoricos, creditos_practicos, prerrequisitos)  
VALUES (026, 'Libertad en Accion 2', 'curso interdisciplinario con otroas facultades con el fin de resolver un problema', 3,3, 'Economia 2');

INSERT INTO Curso (codigo_curso, nombre_curso, descripcion, creditos_teoricos, creditos_practicos, prerrequisitos)  
VALUES (054, 'Etica Profesional', 'curso interdisciplinario el cual consiste en una pasantia en el mundo profesional', 3,3, 'Etica de la Libertad');

INSERT INTO Curso (codigo_curso, nombre_curso, descripcion, creditos_teoricos, creditos_practicos, prerrequisitos)  
VALUES (055, 'Cloud & Inhouse Infrastructure', 'curso  acerca de la nube', 3,3, 'N/A');

INSERT INTO Curso (codigo_curso, nombre_curso, descripcion, creditos_teoricos, creditos_practicos, prerrequisitos)  
VALUES (056, 'Taller Avanzado de Computer Science', 'curso de proyectos relacionados con la carrera', 3,3, 'N/A');

INSERT INTO Curso (codigo_curso, nombre_curso, descripcion, creditos_teoricos, creditos_practicos, prerrequisitos)  
VALUES (057, 'Technologies and Freedom', 'curso acerca de de como las tecnologias se utilizan en el mundo profesional', 3,3, 'N/A');

INSERT INTO Curso (codigo_curso, nombre_curso, descripcion, creditos_teoricos, creditos_practicos, prerrequisitos)  
VALUES (058, 'Seguridad informatica & Encriptacion', 'curso acerca de como se utiliza la encripacion en la cyberseguridad', 3,3, 'Introduccion a Redes');

INSERT INTO Curso (codigo_curso, nombre_curso, descripcion, creditos_teoricos, creditos_practicos, prerrequisitos)  
VALUES (059, 'Computer Vision', 'curso acerca de data science relacionado con la vision del computador', 3,3, 'N/A');

INSERT INTO Curso (codigo_curso, nombre_curso, descripcion, creditos_teoricos, creditos_practicos, prerrequisitos)  
VALUES (060, 'Lean Six Sigma', 'curso metodología de mejora de procesos', 3,3, 'Statistical Thinking 1');

INSERT INTO Curso (codigo_curso, nombre_curso, descripcion, creditos_teoricos, creditos_practicos, prerrequisitos)  
VALUES (061, 'Inteligencia Artificial', 'curso acerca de AI como se utiliza , funciona y comprende', 3,3, 'N/A');

SELECT * FROM cuRSO 
;

SELECT * FROM cuRSO 
ORDER BY codigo_curso ;

SELECT * FROM cuRSO 
ORDER BY codigo_curso ;

INSERT INTO Curso (codigo_curso, nombre_curso, descripcion, creditos_teoricos, creditos_practicos, prerrequisitos)  
VALUES (008, 'Global Management', 'Introduccion a analisis economico', 3,3, 'N/A');

INSERT INTO Curso (codigo_curso, nombre_curso, descripcion, creditos_teoricos, creditos_practicos, prerrequisitos)  
VALUES (009, 'Intro a la Mate', 'Estandarizacion de procesos matematicos', 3,3, 'N/A');

INSERT INTO Curso (codigo_curso, nombre_curso, descripcion, creditos_teoricos, creditos_practicos, prerrequisitos)  
VALUES (010, 'Matematicas 101', 'Introduccion a Matematicas Universitarias', 3,3, 'N/A');

INSERT INTO Curso (codigo_curso, nombre_curso, descripcion, creditos_teoricos, creditos_practicos, prerrequisitos)  
VALUES (011, 'Economia 1', 'Introduccion a Economia', 3,3, 'N/A');

INSERT INTO Curso (codigo_curso, nombre_curso, descripcion, creditos_teoricos, creditos_practicos, prerrequisitos)  
VALUES (012, 'Programacion 1', 'Introduccion a programacion', 3,3, 'N/A');

INSERT INTO Curso (codigo_curso, nombre_curso, descripcion, creditos_teoricos, creditos_practicos, prerrequisitos)  
VALUES (013, 'Programacion Digital', 'Introduccion a compuertas logicas', 3,3, 'N/A');

INSERT INTO Curso (codigo_curso, nombre_curso, descripcion, creditos_teoricos, creditos_practicos, prerrequisitos)  
VALUES (014, 'Liderazgo Empresarial', 'Como ser un lider en una empresa', 3,3, 'N/A');

INSERT INTO Curso (codigo_curso, nombre_curso, descripcion, creditos_teoricos, creditos_practicos, prerrequisitos)  
VALUES (015, 'User Experience', 'Como tener un buen UX', 3,3, 'N/A');

INSERT INTO Curso (codigo_curso, nombre_curso, descripcion, creditos_teoricos, creditos_practicos, prerrequisitos)  
VALUES (016, 'Razonamiento Critico', 'Pensamientos que se deben tomar', 3,3, 'N/A');

INSERT INTO Curso (codigo_curso, nombre_curso, descripcion, creditos_teoricos, creditos_practicos, prerrequisitos)  
VALUES (017, 'Asesoria Linguistica', 'Aprender a escribir de forma correcta', 3,3, 'N/A');

SELECT * FROM cuRSO 
ORDER BY codigo_curso ;

SELECT * FROM cuRSO 
ORDER BY codigo_curso ;

SELECT * FROM cuRSO 
ORDER BY codigo_curso ;

SELECT * FROM cuRSO 
ORDER BY codigo_curso ;

SELECT * FROM cuRSO 
ORDER BY codigo_curso ;

Update curso 
set creditos_practicos = 1, creditos_teoricos = 1 
where codigo_curso = 017;

SELECT * FROM cuRSO 
ORDER BY codigo_curso ;

INSERT INTO Curso (codigo_curso, nombre_curso, descripcion, creditos_teoricos, creditos_practicos, prerrequisitos)  
VALUES (027, 'Intro al Derecho', 'Introduccion a las leyes', 3,3, 'Global Management');

INSERT INTO Curso (codigo_curso, nombre_curso, descripcion, creditos_teoricos, creditos_practicos, prerrequisitos)  
VALUES (036, 'Accounting', 'Introduccion a la contabilidad', 3,3, 'N/A');

INSERT INTO Curso (codigo_curso, nombre_curso, descripcion, creditos_teoricos, creditos_practicos, prerrequisitos)  
VALUES (037, 'Calculo Diferencial', 'Matematicas con enfoque a diferenciales', 3,3, 'Into a la Mate');

INSERT INTO Curso (codigo_curso, nombre_curso, descripcion, creditos_teoricos, creditos_practicos, prerrequisitos)  
VALUES (038, 'Intro a la Filosofia', 'Introduccion a la filosofia', 3,3, 'Razonamiento Critico');

INSERT INTO Curso (codigo_curso, nombre_curso, descripcion, creditos_teoricos, creditos_practicos, prerrequisitos)  
VALUES (039, 'Economia 2', 'Seguimiento del curso de economia 1', 3,3, 'Economia 1');

INSERT INTO Curso (codigo_curso, nombre_curso, descripcion, creditos_teoricos, creditos_practicos, prerrequisitos)  
VALUES (040, 'Progra de Dispositivos Electronicos', 'Programacion enfocada a dispositivos', 3,3, 'Programacion 1');

INSERT INTO Curso (codigo_curso, nombre_curso, descripcion, creditos_teoricos, creditos_practicos, prerrequisitos)  
VALUES (041, 'Progra Orientada a Objetos', 'Programacion 2', 3,3, 'Programacion 1');

INSERT INTO Curso (codigo_curso, nombre_curso, descripcion, creditos_teoricos, creditos_practicos, prerrequisitos)  
VALUES (042, 'Matematica Discreta Aplicada', 'Matematicas aplicadas a programacion', 3,3, 'Programacion 1');

SELECT * FROM cuRSO 
ORDER BY codigo_curso ;

INSERT INTO Curso (codigo_curso, nombre_curso, descripcion, creditos_teoricos, creditos_practicos, prerrequisitos)  
VALUES (043, 'Marketing', 'Introduccion al marketing', 3,3, 'Global Management');

INSERT INTO Curso (codigo_curso, nombre_curso, descripcion, creditos_teoricos, creditos_practicos, prerrequisitos)  
VALUES (044, 'Statistical Thinking 1', 'Estadistica 1', 3,3, 'Calculo Diferencial');

INSERT INTO Curso (codigo_curso, nombre_curso, descripcion, creditos_teoricos, creditos_practicos, prerrequisitos)  
VALUES (045, 'Calculo Integral', 'Matematicas enfocadas a integrales', 3,3, 'Calculo Diferencial');

INSERT INTO Curso (codigo_curso, nombre_curso, descripcion, creditos_teoricos, creditos_practicos, prerrequisitos)  
VALUES (046, 'Etica de la Libertad', 'Pensamiento hacia la libertad', 3,3, 'Economia 2');

INSERT INTO Curso (codigo_curso, nombre_curso, descripcion, creditos_teoricos, creditos_practicos, prerrequisitos)  
VALUES (047, 'Microeconomia', 'Vista de aspecto micro hacia la economia', 3,3, 'Economia 2');

INSERT INTO Curso (codigo_curso, nombre_curso, descripcion, creditos_teoricos, creditos_practicos, prerrequisitos)  
VALUES (048, 'Estructura de Datos', 'Aprender como estucturar data', 3,3, 'Progra Orientada a Objetos');

INSERT INTO Curso (codigo_curso, nombre_curso, descripcion, creditos_teoricos, creditos_practicos, prerrequisitos)  
VALUES (049, 'Cost Analysis', 'Analisis de cotos de una empresa', 3,3, 'Accounting');

INSERT INTO Curso (codigo_curso, nombre_curso, descripcion, creditos_teoricos, creditos_practicos, prerrequisitos)  
VALUES (050, 'Innovation', 'Uso de Scrum en empresas', 3,3, 'N/A');

SELECT * FROM cuRSO 
ORDER BY codigo_curso ;

SELECT count(codigo_curso) FROM cuRSO 
;

SELECT * FROM cuRSO 
ORDER BY codigo_curso ;

SELECT * FROM cuRSO 
ORDER BY codigo_curso desc;

INSERT INTO Curso (codigo_curso, nombre_curso, descripcion, creditos_teoricos, creditos_practicos, prerrequisitos)  
VALUES (051, 'Scientific Computing', 'Progra avanzada', 3,3, 'Calculo Integral');

INSERT INTO Curso (codigo_curso, nombre_curso, descripcion, creditos_teoricos, creditos_practicos, prerrequisitos)  
VALUES (052, 'Global Management 2', 'Seguimiento de Global 1', 3,3, 'Global Management 1');

INSERT INTO Curso (codigo_curso, nombre_curso, descripcion, creditos_teoricos, creditos_practicos, prerrequisitos)  
VALUES (053, 'Administracion Financiera', 'Finanzas', 3,3, 'Calculo Integral');

INSERT INTO Curso (codigo_curso, nombre_curso, descripcion, creditos_teoricos, creditos_practicos, prerrequisitos)  
VALUES (062, 'Statistical Thinking 2', 'EStadistica 2', 3,3, 'Statistical Thinking 1');

INSERT INTO Curso (codigo_curso, nombre_curso, descripcion, creditos_teoricos, creditos_practicos, prerrequisitos)  
VALUES (063, 'Algebra Lineal', 'Utilizacion de matrices matematicas', 3,3, 'Calculo Integral');

INSERT INTO Curso (codigo_curso, nombre_curso, descripcion, creditos_teoricos, creditos_practicos, prerrequisitos)  
VALUES (064, 'Teorias Monetarias', 'Teorias monetarias en la sociedad', 3,3, 'Microeconomia');

INSERT INTO Curso (codigo_curso, nombre_curso, descripcion, creditos_teoricos, creditos_practicos, prerrequisitos)  
VALUES (065, 'Algoritmia y Complejidad', 'Programacion Avanzada', 3,3, 'Estructura de Datos');

INSERT INTO Curso (codigo_curso, nombre_curso, descripcion, creditos_teoricos, creditos_practicos, prerrequisitos)  
VALUES (066, 'Automation Testing', 'Automatizacion de codigo', 1,1, 'Innovation');

INSERT INTO Curso (codigo_curso, nombre_curso, descripcion, creditos_teoricos, creditos_practicos, prerrequisitos)  
VALUES (067, 'DavOps', 'Programacion avanzada', 1,1, 'Innovation');

SELECT count(codigo_curso) FROM cuRSO;

SELECT * 
    FROM cuRSO;

SELECT * 
    FROM cuRSO 
ORDER BY codigo_curso desc;

SELECT * FROM cuRSO 
    where nombre_curso = 'data_science' 
ORDER BY codigo_curso desc;

SELECT * FROM cuRSO 
    
ORDER BY codigo_curso desc;

SELECT * FROM cuRSO 
    
ORDER BY codigo_curso desc;

SELECT * FROM cuRSO 
    where nombre_curso = 'Data Science' 
ORDER BY codigo_curso desc;

SELECT * FROM cuRSO 
    
ORDER BY codigo_curso desc;

Update curso 
set nombre_curso = 'DevOps' 
where codigo_curso = 067;

SELECT * FROM cuRSO 
    
ORDER BY codigo_curso desc;

SELECT * FROM cuRSO 
    
ORDER BY nombre_curso desc;

SELECT * FROM cuRSO 
    
ORDER BY nombre_curso;

SELECT * FROM cuRSO 
   where nombre_curso = 'Datos 1' 
ORDER BY nombre_curso;

INSERT INTO Curso (codigo_curso, nombre_curso, descripcion, creditos_teoricos, creditos_practicos, prerrequisitos)  
VALUES (068, 'Data Science', 'Utilizacion de data con graficas', 3,3, 'Statistical Thinking 1');

SELECT * FROM cuRSO 
   where nombre_curso = 'Libertad en Accion 1' 
ORDER BY nombre_curso;

SELECT * FROM cuRSO 
   where nombre_curso = 'Libertad en Accion' 
ORDER BY nombre_curso;

INSERT INTO Curso (codigo_curso, nombre_curso, descripcion, creditos_teoricos, creditos_practicos, prerrequisitos)  
VALUES (069, 'Libertad en Accion 1', 'Introduccion al pensamiento de libertad', 3,3, 'Economia 2');

SELECT * FROM cuRSO 
   where nombre_curso = 'Libertad en Accion 1' 
ORDER BY nombre_curso;

SELECT * FROM cuRSO 
    
ORDER BY nombre_curso;

Update curso 
set nombre_curso = 'Administracion Financiera 1' 
where codigo_curso = 053;

SELECT * FROM cuRSO 
    
ORDER BY nombre_curso;

Update curso 
set prerrequisitos = 'Global Management' 
where codigo_curso = 052;

SELECT * FROM cuRSO 
    
ORDER BY nombre_curso;

SELECT * FROM cuRSO 
    
ORDER BY nombre_curso desc;

SELECT * FROM cuRSO 
    
ORDER BY codigo_curso;

Update curso 
set prerrequisitos = 'Algebra Lineal' 
where codigo_curso = 001 
set prerrequisitos = 'Economia 2' 
where codigo_curso = 002;

Update curso 
set prerrequisitos = 'Algebra Lineal' 
where codigo_curso = 001;

set prerrequisitos = 'Economia 2' 


where codigo_curso = 002;


Update curso 
set prerrequisitos = 'Economia 2' 
where codigo_curso = 002;

SELECT * FROM cuRSO 
    
ORDER BY codigo_curso;

Update curso 
set prerrequisitos = 'Statistical Thinking 2' 
where codigo_curso = 003;

SELECT * FROM cuRSO 
    
ORDER BY codigo_curso;

SELECT * FROM cuRSO 
    
ORDER BY codigo_curso;

SELECT * FROM cuRSO 
    
ORDER BY codigo_curso;

Update curso 
set prerrequisitos = 'Microeconomia' 
where codigo_curso = 004;

SELECT * FROM cuRSO 
    
ORDER BY codigo_curso;

Update curso 
set prerrequisitos = 'Estructura de Datos' 
where codigo_curso = 005;

SELECT * FROM cuRSO 
    
ORDER BY codigo_curso;

Update curso 
set prerrequisitos = 'Algebra Lineal' 
where codigo_curso = 006;

SELECT * FROM cuRSO 
    
ORDER BY codigo_curso;

Update curso 
set prerrequisitos = 'Estructura de Datos' 
where codigo_curso = 007;

SELECT * FROM cuRSO 
    
ORDER BY codigo_curso;

SELECT count(codigo_curso) FROM cuRSO 
    
ORDER BY codigo_curso;

SELECT * FROM Estudiantes;

SELECT * FROM Estudiantes;

INSERT INTO Estudiantes (carnet, nombre, apellido, apellido_2, sexo, decha_de_nacimiento, Direccion, telefono, correo_electronico, numero_cuenta_corriente, ano_entrada)  
VALUES (20210003, 'Javier', 'Caniz', 'Meng', 'M', TO_DATE('21-02-2002', 'DD-MM-YYYY'), 'Condominio Monte Vista Club', 59494970, 'javiercaniz@ufm.edu', 123456789, 2020);

INSERT INTO Estudiantes (carnet, nombre, apellido, apellido_2, sexo, fecha_de_nacimiento, Direccion, telefono, correo_electronico, numero_cuenta_corriente, ano_entrada)  
VALUES (20210003, 'Javier', 'Caniz', 'Meng', 'M', TO_DATE('21-02-2002', 'DD-MM-YYYY'), 'Condominio Monte Vista Club', 59494970, 'javiercaniz@ufm.edu', 123456789, 2020);

INSERT INTO Estudiantes (carnet, nombre, apellido, apeliido_2, sexo, fecha_de_nacimiento, Direccion, telefono, correo_electronico, numero_cuenta_corriente, ano_entrada)  
VALUES (20210003, 'Javier', 'Caniz', 'Meng', 'M', TO_DATE('21-02-2002', 'DD-MM-YYYY'), 'Condominio Monte Vista Club', 59494970, 'javiercaniz@ufm.edu', 123456789, 2020);

SELECT * FROM Estudiantes;

INSERT INTO Estudiantes (carnet, nombre, apellido, apeliido_2, sexo, fecha_de_nacimiento, Direccion, telefono, correo_electronico, numero_cuenta_corriente, ano_entrada)  
VALUES (20210030, 'Milton', 'Beltran', 'Cordon', 'M', TO_DATE('18-08-2003', 'DD-MM-YYYY'), '4 calle 8 avenida', 68135796, 'miltonbertran@ufm.edu', 987654321, 2021);

INSERT INTO Estudiantes (carnet, nombre, apellido, apeliido_2, sexo, fecha_de_nacimiento, Direccion, telefono, correo_electronico, numero_cuenta_corriente, ano_entrada)  
VALUES (20210104, 'Keneth', 'Ruiz', '.', 'M', TO_DATE('13-04-2002', 'DD-MM-YYYY'), '3-80 zona 14', 57932255, 'kgruiz@ufm.edu', 687269368, 2020);

SELECT * FROM Estudiantes;

select * from curso;

select * from curso 
order by codigo_curso;

select * from curso 
order by codigo_curso;

Alter Table Asignaciones 
ADD FOREIGN KEY (id_estudiante) REFERENCES Estudiantes(carnet);

Alter Table Asignaciones 
ADD FOREIGN KEY (id_estudiante) REFERENCES Estudiantes(carnet);

Alter Table Asignacion 
ADD FOREIGN KEY (id_estudiante) REFERENCES Estudiantes(carnet);

Alter Table Asignacion 
add id_estudiante INT 
ADD FOREIGN KEY (id_estudiante) REFERENCES Estudiantes(carnet);

select * from asignacion;

INSERT INTO Asignacion (id, posible, estado_curso, nota_curso, realizacion_retiro, id_estudiante)  
VALUES (1, 'Posible valor', 'Estado del curso', 85.00, 'Realizacion/Retiro', 123456);

Alter table asignacion 
drop column posible;

Alter Table Asignacion 
add id_curso INT 
ADD FOREIGN KEY (id_curso) REFERENCES Curso(codigo_curso);

select * from Curso 
order by codigo_curso;

select * from Curso 
order by codigo_curso desc;

INSERT INTO Asignacion (id,  estado_curso, nota_curso, realizacion_retiro, id_estudiante, id_curso)  
VALUES (1, 'Aprovado', 85.00, 'Realizado', 20210003,8);

INSERT INTO Asignacion (id,  estado_curso, nota_curso, realizacion_retiro, id_estudiante, id_curso)  
VALUES (1, 'Aprovado', 80.00, 'Realizado', 20210030,8);

INSERT INTO Asignacion (id,  estado_curso, nota_curso, realizacion_retiro, id_estudiante, id_curso)  
VALUES (2, 'Aprovado', 80.00, 'Realizado', 20210030,8);

INSERT INTO Asignacion (id,  estado_curso, nota_curso, realizacion_retiro, id_estudiante, id_curso)  
VALUES (3, 'Aprovado', 90.00, 'Realizado', 20210104,8);

select * from asignacion;

INSERT INTO Asignacion (id,  estado_curso, nota_curso, realizacion_retiro, id_estudiante, id_curso)  
VALUES (4, 'Aprovado', 70.00, 'Realizado', 20210104,9);

INSERT INTO Asignacion (id,  estado_curso, nota_curso, realizacion_retiro, id_estudiante, id_curso)  
VALUES (5, 'Aprovado', 85.00, 'Realizado', 20210003,9);

INSERT INTO Asignacion (id,  estado_curso, nota_curso, realizacion_retiro, id_estudiante, id_curso)  
VALUES (6, 'Aprovado', 90.00, 'Realizado', 20210030,9);

INSERT INTO Asignacion (id,  estado_curso, nota_curso, realizacion_retiro, id_estudiante, id_curso)  
VALUES (7, 'Aprovado', 83.00, 'Realizado', 20210104,10);

INSERT INTO Asignacion (id,  estado_curso, nota_curso, realizacion_retiro, id_estudiante, id_curso)  
VALUES (8, 'Aprovado', 92.00, 'Realizado', 20210003,10);

INSERT INTO Asignacion (id,  estado_curso, nota_curso, realizacion_retiro, id_estudiante, id_curso)  
VALUES (9, 'Aprovado', 73.00, 'Realizado', 20210030,10);

select * from asignacion;

select * from asignacion 
    order by id;

INSERT INTO Asignacion (id,  estado_curso, nota_curso, realizacion_retiro, id_estudiante, id_curso)  
VALUES (10, 'Aprovado', 88.00, 'Realizado', 20210104,11);

INSERT INTO Asignacion (id,  estado_curso, nota_curso, realizacion_retiro, id_estudiante, id_curso)  
VALUES (11, 'Aprovado', 72.00, 'Realizado', 20210003,11);

INSERT INTO Asignacion (id,  estado_curso, nota_curso, realizacion_retiro, id_estudiante, id_curso)  
VALUES (12, 'Aprovado', 94.00, 'Realizado', 20210030,11);

INSERT INTO Asignacion (id,  estado_curso, nota_curso, realizacion_retiro, id_estudiante, id_curso)  
VALUES (13, 'Aprovado', 100.00, 'Realizado', 20210104,12);

INSERT INTO Asignacion (id,  estado_curso, nota_curso, realizacion_retiro, id_estudiante, id_curso)  
VALUES (14, 'Aprovado', 100.00, 'Realizado', 20210003,12);

INSERT INTO Asignacion (id,  estado_curso, nota_curso, realizacion_retiro, id_estudiante, id_curso)  
VALUES (15, 'Aprovado', 99.00, 'Realizado', 20210030,12);

INSERT INTO Asignacion (id,  estado_curso, nota_curso, realizacion_retiro, id_estudiante, id_curso)  
VALUES (16, 'Aprovado', 87.00, 'Realizado', 20210104,13);

INSERT INTO Asignacion (id,  estado_curso, nota_curso, realizacion_retiro, id_estudiante, id_curso)  
VALUES (17, 'Aprovado', 93.00, 'Realizado', 20210003,13);

INSERT INTO Asignacion (id,  estado_curso, nota_curso, realizacion_retiro, id_estudiante, id_curso)  
VALUES (18, 'Aprovado', 75.00, 'Realizado', 20210030,13);

INSERT INTO Asignacion (id,  estado_curso, nota_curso, realizacion_retiro, id_estudiante, id_curso)  
VALUES (19, 'Aprovado', 99.00, 'Realizado', 20210104,14);

INSERT INTO Asignacion (id,  estado_curso, nota_curso, realizacion_retiro, id_estudiante, id_curso)  
VALUES (20, 'Aprovado', 82.00, 'Realizado', 20210003,14);

INSERT INTO Asignacion (id,  estado_curso, nota_curso, realizacion_retiro, id_estudiante, id_curso)  
VALUES (21, 'Aprovado', 100.00, 'Realizado', 20210030,14);

INSERT INTO Asignacion (id,  estado_curso, nota_curso, realizacion_retiro, id_estudiante, id_curso)  
VALUES (22, 'Aprovado', 85.00, 'Realizado', 20210104,15);

INSERT INTO Asignacion (id,  estado_curso, nota_curso, realizacion_retiro, id_estudiante, id_curso)  
VALUES (23, 'Aprovado', 91.00, 'Realizado', 20210003,15);

INSERT INTO Asignacion (id,  estado_curso, nota_curso, realizacion_retiro, id_estudiante, id_curso)  
VALUES (24, 'Aprovado', 78.00, 'Realizado', 20210030,15);

select * from asignacion 
    order by id;

INSERT INTO Asignacion (id,  estado_curso, nota_curso, realizacion_retiro, id_estudiante, id_curso)  
VALUES (25, 'En Proceso', 0.00, 'Pendiente', 20210104,1);

INSERT INTO Asignacion (id,  estado_curso, nota_curso, realizacion_retiro, id_estudiante, id_curso)  
VALUES (26, 'En Proceso', 0.00, 'Pendiente', 20210003,1);

INSERT INTO Asignacion (id,  estado_curso, nota_curso, realizacion_retiro, id_estudiante, id_curso)  
VALUES (27, 'En Proceso', 0.00, 'Pendiente', 20210030,1);

INSERT INTO Asignacion (id,  estado_curso, nota_curso, realizacion_retiro, id_estudiante, id_curso)  
VALUES (28, 'En Proceso', 0.00, 'Pendiente', 20210104,2);

INSERT INTO Asignacion (id,  estado_curso, nota_curso, realizacion_retiro, id_estudiante, id_curso)  
VALUES (29, 'En Proceso', 0.00, 'Pendiente', 20210003,2);

INSERT INTO Asignacion (id,  estado_curso, nota_curso, realizacion_retiro, id_estudiante, id_curso)  
VALUES (30, 'En Proceso', 0.00, 'Pendiente', 20210030,2);

INSERT INTO Asignacion (id,  estado_curso, nota_curso, realizacion_retiro, id_estudiante, id_curso)  
VALUES (31, 'En Proceso', 0.00, 'Pendiente', 20210104,3);

INSERT INTO Asignacion (id,  estado_curso, nota_curso, realizacion_retiro, id_estudiante, id_curso)  
VALUES (32, 'En Proceso', 0.00, 'Pendiente', 20210003,3);

INSERT INTO Asignacion (id,  estado_curso, nota_curso, realizacion_retiro, id_estudiante, id_curso)  
VALUES (33, 'En Proceso', 0.00, 'Pendiente', 20210030,3);

select * from asignacion 
    order by id;

INSERT INTO Asignacion (id,  estado_curso, nota_curso, realizacion_retiro, id_estudiante, id_curso)  
VALUES (34, 'En Proceso', 0.00, 'Pendiente', 20210104,4);

INSERT INTO Asignacion (id,  estado_curso, nota_curso, realizacion_retiro, id_estudiante, id_curso)  
VALUES (35, 'En Proceso', 0.00, 'Pendiente', 20210003,4);

INSERT INTO Asignacion (id,  estado_curso, nota_curso, realizacion_retiro, id_estudiante, id_curso)  
VALUES (36, 'En Proceso', 0.00, 'Pendiente', 20210030,4);

INSERT INTO Asignacion (id,  estado_curso, nota_curso, realizacion_retiro, id_estudiante, id_curso)  
VALUES (37, 'En Proceso', 0.00, 'Pendiente', 20210104,5);

INSERT INTO Asignacion (id,  estado_curso, nota_curso, realizacion_retiro, id_estudiante, id_curso)  
VALUES (38, 'En Proceso', 0.00, 'Pendiente', 20210003,5);

INSERT INTO Asignacion (id,  estado_curso, nota_curso, realizacion_retiro, id_estudiante, id_curso)  
VALUES (39, 'En Proceso', 0.00, 'Pendiente', 20210030,5);

INSERT INTO Asignacion (id,  estado_curso, nota_curso, realizacion_retiro, id_estudiante, id_curso)  
VALUES (40, 'En Proceso', 0.00, 'Pendiente', 20210104,6);

INSERT INTO Asignacion (id,  estado_curso, nota_curso, realizacion_retiro, id_estudiante, id_curso)  
VALUES (41, 'En Proceso', 0.00, 'Pendiente', 20210003,6);

INSERT INTO Asignacion (id,  estado_curso, nota_curso, realizacion_retiro, id_estudiante, id_curso)  
VALUES (42, 'En Proceso', 0.00, 'Pendiente', 20210030,6);

INSERT INTO Asignacion (id,  estado_curso, nota_curso, realizacion_retiro, id_estudiante, id_curso)  
VALUES (43, 'En Proceso', 0.00, 'Pendiente', 20210104,7);

INSERT INTO Asignacion (id,  estado_curso, nota_curso, realizacion_retiro, id_estudiante, id_curso)  
VALUES (44, 'En Proceso', 0.00, 'Pendiente', 20210003,7);

INSERT INTO Asignacion (id,  estado_curso, nota_curso, realizacion_retiro, id_estudiante, id_curso)  
VALUES (45, 'En Proceso', 0.00, 'Pendiente', 20210030,7);

select * from asignacion 
    order by id;

INSERT INTO Asignacion (id,  estado_curso, nota_curso, realizacion_retiro, id_estudiante, id_curso)  
VALUES (130, 'Aprovado', 90.00, 'Realizado', 20210104,44);

INSERT INTO Asignacion (id,  estado_curso, nota_curso, realizacion_retiro, id_estudiante, id_curso)  
VALUES (131, 'Aprovado', 80.00, 'Realizado', 20210003,44);

INSERT INTO Asignacion (id,  estado_curso, nota_curso, realizacion_retiro, id_estudiante, id_curso)  
VALUES (132, 'Aprovado', 85.00, 'Realizado', 20210030,44);

INSERT INTO Asignacion (id,  estado_curso, nota_curso, realizacion_retiro, id_estudiante, id_curso)  
VALUES (133, 'Aprovado', 69.00, 'Realizado', 20210104,45);

INSERT INTO Asignacion (id,  estado_curso, nota_curso, realizacion_retiro, id_estudiante, id_curso)  
VALUES (134, 'Aprovado', 73.00, 'Realizado', 20210003,45);

INSERT INTO Asignacion (id,  estado_curso, nota_curso, realizacion_retiro, id_estudiante, id_curso)  
VALUES (135, 'Aprovado', 74.00, 'Realizado', 20210030,45);

INSERT INTO Asignacion (id,  estado_curso, nota_curso, realizacion_retiro, id_estudiante, id_curso)  
VALUES (136, 'Aprovado', 90.00, 'Realizado', 20210104,46);

INSERT INTO Asignacion (id,  estado_curso, nota_curso, realizacion_retiro, id_estudiante, id_curso)  
VALUES (137, 'Aprovado', 89.00, 'Realizado', 20210003,46);

INSERT INTO Asignacion (id,  estado_curso, nota_curso, realizacion_retiro, id_estudiante, id_curso)  
VALUES (138, 'Aprovado', 93.00, 'Realizado', 20210030,46);

INSERT INTO Asignacion (id,  estado_curso, nota_curso, realizacion_retiro, id_estudiante, id_curso)  
VALUES (139, 'Aprovado', 87.00, 'Realizado', 20210104,47);

INSERT INTO Asignacion (id,  estado_curso, nota_curso, realizacion_retiro, id_estudiante, id_curso)  
VALUES (140, 'Aprovado', 74.00, 'Realizado', 20210003,47);

INSERT INTO Asignacion (id,  estado_curso, nota_curso, realizacion_retiro, id_estudiante, id_curso)  
VALUES (141, 'Aprovado', 73.00, 'Realizado', 20210030,47);

INSERT INTO Asignacion (id,  estado_curso, nota_curso, realizacion_retiro, id_estudiante, id_curso)  
VALUES (142, 'Aprovado', 80.00, 'Realizado', 20210104,48);

INSERT INTO Asignacion (id,  estado_curso, nota_curso, realizacion_retiro, id_estudiante, id_curso)  
VALUES (143, 'Aprovado', 90.00, 'Realizado', 20210003,48);

INSERT INTO Asignacion (id,  estado_curso, nota_curso, realizacion_retiro, id_estudiante, id_curso)  
VALUES (144, 'Aprovado', 85.00, 'Realizado', 20210030,48);

INSERT INTO Asignacion (id,  estado_curso, nota_curso, realizacion_retiro, id_estudiante, id_curso)  
VALUES (145, 'Aprovado', 79.00, 'Realizado', 20210104,49);

INSERT INTO Asignacion (id,  estado_curso, nota_curso, realizacion_retiro, id_estudiante, id_curso)  
VALUES (146, 'Aprovado', 91.00, 'Realizado', 20210003,49);

INSERT INTO Asignacion (id,  estado_curso, nota_curso, realizacion_retiro, id_estudiante, id_curso)  
VALUES (147, 'Aprovado', 91.00, 'Realizado', 20210030,49);

INSERT INTO Asignacion (id,  estado_curso, nota_curso, realizacion_retiro, id_estudiante, id_curso)  
VALUES (148, 'Aprovado', 89.00, 'Realizado', 20210104,50);

INSERT INTO Asignacion (id,  estado_curso, nota_curso, realizacion_retiro, id_estudiante, id_curso)  
VALUES (149, 'Aprovado', 79.00, 'Realizado', 20210003,50);

INSERT INTO Asignacion (id,  estado_curso, nota_curso, realizacion_retiro, id_estudiante, id_curso)  
VALUES (150, 'Aprovado', 83.00, 'Realizado', 20210030,50);

INSERT INTO Asignacion (id,  estado_curso, nota_curso, realizacion_retiro, id_estudiante, id_curso)  
VALUES (151, 'Aprovado', 79.00, 'Realizado', 20210104,51);

INSERT INTO Asignacion (id,  estado_curso, nota_curso, realizacion_retiro, id_estudiante, id_curso)  
VALUES (152, 'Aprovado', 78.00, 'Realizado', 20210003,51);

INSERT INTO Asignacion (id,  estado_curso, nota_curso, realizacion_retiro, id_estudiante, id_curso)  
VALUES (153, 'Aprovado', 90.00, 'Realizado', 20210030,51);

INSERT INTO Asignacion (id,  estado_curso, nota_curso, realizacion_retiro, id_estudiante, id_curso)  
VALUES (154, 'Aprovado', 91.00, 'Realizado', 20210104,52);

INSERT INTO Asignacion (id,  estado_curso, nota_curso, realizacion_retiro, id_estudiante, id_curso)  
VALUES (155, 'Aprovado', 88.00, 'Realizado', 20210003,52);

INSERT INTO Asignacion (id,  estado_curso, nota_curso, realizacion_retiro, id_estudiante, id_curso)  
VALUES (156, 'Aprovado', 90.00, 'Realizado', 20210030,52);

INSERT INTO Asignacion (id,  estado_curso, nota_curso, realizacion_retiro, id_estudiante, id_curso)  
VALUES (157, 'Aprovado', 85.00, 'Realizado', 20210104,52);

INSERT INTO Asignacion (id,  estado_curso, nota_curso, realizacion_retiro, id_estudiante, id_curso)  
VALUES (158, 'Aprovado', 90.00, 'Realizado', 20210003,52);

INSERT INTO Asignacion (id,  estado_curso, nota_curso, realizacion_retiro, id_estudiante, id_curso)  
VALUES (159, 'Aprovado', 73.00, 'Realizado', 20210030,52);

INSERT INTO Asignacion (id,  estado_curso, nota_curso, realizacion_retiro, id_estudiante, id_curso)  
VALUES (160, 'Pendiente', 0.00, 'Pendiente', 20210104,53);

INSERT INTO Asignacion (id,  estado_curso, nota_curso, realizacion_retiro, id_estudiante, id_curso)  
VALUES (161, 'Pendiente', 0.00, 'Pendiente', 20210003,53);

INSERT INTO Asignacion (id,  estado_curso, nota_curso, realizacion_retiro, id_estudiante, id_curso)  
VALUES (162, 'Pendiente', 0.00, 'Pendiente', 20210030,53);

select * from asignacion 
    order by id desc;

INSERT INTO Asignacion (id,  estado_curso, nota_curso, realizacion_retiro, id_estudiante, id_curso)  
VALUES (163, 'Pendiente', 0.00, 'Pendiente', 20210104,54);

INSERT INTO Asignacion (id,  estado_curso, nota_curso, realizacion_retiro, id_estudiante, id_curso)  
VALUES (164, 'Pendiente', 0.00, 'Pendiente', 20210003,54);

INSERT INTO Asignacion (id,  estado_curso, nota_curso, realizacion_retiro, id_estudiante, id_curso)  
VALUES (165, 'Pendiente', 0.00, 'Pendiente', 20210030,54);

INSERT INTO Asignacion (id,  estado_curso, nota_curso, realizacion_retiro, id_estudiante, id_curso)  
VALUES (166, 'Pendiente', 0.00, 'Pendiente', 20210104,55);

INSERT INTO Asignacion (id,  estado_curso, nota_curso, realizacion_retiro, id_estudiante, id_curso)  
VALUES (167, 'Pendiente', 0.00, 'Pendiente', 20210003,55);

INSERT INTO Asignacion (id,  estado_curso, nota_curso, realizacion_retiro, id_estudiante, id_curso)  
VALUES (168, 'Pendiente', 0.00, 'Pendiente', 20210030,55);

INSERT INTO Asignacion (id,  estado_curso, nota_curso, realizacion_retiro, id_estudiante, id_curso)  
VALUES (169, 'Pendiente', 0.00, 'Pendiente', 20210104,56);

INSERT INTO Asignacion (id,  estado_curso, nota_curso, realizacion_retiro, id_estudiante, id_curso)  
VALUES (170, 'Pendiente', 0.00, 'Pendiente', 20210003,56);

INSERT INTO Asignacion (id,  estado_curso, nota_curso, realizacion_retiro, id_estudiante, id_curso)  
VALUES (171, 'Pendiente', 0.00, 'Pendiente', 20210030,56);

select * from asignacion 
    order by id desc;

INSERT INTO Asignacion (id,  estado_curso, nota_curso, realizacion_retiro, id_estudiante, id_curso)  
VALUES (172, 'Pendiente', 0.00, 'Pendiente', 20210104,57);

INSERT INTO Asignacion (id,  estado_curso, nota_curso, realizacion_retiro, id_estudiante, id_curso)  
VALUES (173, 'Pendiente', 0.00, 'Pendiente', 20210003,57);

INSERT INTO Asignacion (id,  estado_curso, nota_curso, realizacion_retiro, id_estudiante, id_curso)  
VALUES (174, 'Pendiente', 0.00, 'Pendiente', 20210030,57);

INSERT INTO Asignacion (id,  estado_curso, nota_curso, realizacion_retiro, id_estudiante, id_curso)  
VALUES (175, 'Pendiente', 0.00, 'Pendiente', 20210104,58);

INSERT INTO Asignacion (id,  estado_curso, nota_curso, realizacion_retiro, id_estudiante, id_curso)  
VALUES (176, 'Pendiente', 0.00, 'Pendiente', 20210003,58);

INSERT INTO Asignacion (id,  estado_curso, nota_curso, realizacion_retiro, id_estudiante, id_curso)  
VALUES (177, 'Pendiente', 0.00, 'Pendiente', 20210030,58);

INSERT INTO Asignacion (id,  estado_curso, nota_curso, realizacion_retiro, id_estudiante, id_curso)  
VALUES (178, 'Pendiente', 0.00, 'Pendiente', 20210104,59);

INSERT INTO Asignacion (id,  estado_curso, nota_curso, realizacion_retiro, id_estudiante, id_curso)  
VALUES (179, 'Pendiente', 0.00, 'Pendiente', 20210003,59);

INSERT INTO Asignacion (id,  estado_curso, nota_curso, realizacion_retiro, id_estudiante, id_curso)  
VALUES (180, 'Pendiente', 0.00, 'Pendiente', 20210030,59);

INSERT INTO Asignacion (id,  estado_curso, nota_curso, realizacion_retiro, id_estudiante, id_curso)  
VALUES (181, 'Pendiente', 0.00, 'Pendiente', 20210104,60);

INSERT INTO Asignacion (id,  estado_curso, nota_curso, realizacion_retiro, id_estudiante, id_curso)  
VALUES (182, 'Pendiente', 0.00, 'Pendiente', 20210003,60);

INSERT INTO Asignacion (id,  estado_curso, nota_curso, realizacion_retiro, id_estudiante, id_curso)  
VALUES (183, 'Pendiente', 0.00, 'Pendiente', 20210030,60);

INSERT INTO Asignacion (id,  estado_curso, nota_curso, realizacion_retiro, id_estudiante, id_curso)  
VALUES (184, 'Pendiente', 0.00, 'Pendiente', 20210104,61);

INSERT INTO Asignacion (id,  estado_curso, nota_curso, realizacion_retiro, id_estudiante, id_curso)  
VALUES (185, 'Pendiente', 0.00, 'Pendiente', 20210003,61);

INSERT INTO Asignacion (id,  estado_curso, nota_curso, realizacion_retiro, id_estudiante, id_curso)  
VALUES (186, 'Pendiente', 0.00, 'Pendiente', 20210030,61);

INSERT INTO Asignacion (id,  estado_curso, nota_curso, realizacion_retiro, id_estudiante, id_curso)  
VALUES (187, 'Pendiente', 0.00, 'Pendiente', 20210104,62);

INSERT INTO Asignacion (id,  estado_curso, nota_curso, realizacion_retiro, id_estudiante, id_curso)  
VALUES (188, 'Pendiente', 0.00, 'Pendiente', 20210003,62);

INSERT INTO Asignacion (id,  estado_curso, nota_curso, realizacion_retiro, id_estudiante, id_curso)  
VALUES (189, 'Pendiente', 0.00, 'Pendiente', 20210030,62);

INSERT INTO Asignacion (id,  estado_curso, nota_curso, realizacion_retiro, id_estudiante, id_curso)  
VALUES (190, 'Pendiente', 0.00, 'Pendiente', 20210104,63);

INSERT INTO Asignacion (id,  estado_curso, nota_curso, realizacion_retiro, id_estudiante, id_curso)  
VALUES (191, 'Pendiente', 0.00, 'Pendiente', 20210003,63);

INSERT INTO Asignacion (id,  estado_curso, nota_curso, realizacion_retiro, id_estudiante, id_curso)  
VALUES (192, 'Pendiente', 0.00, 'Pendiente', 20210030,63);

INSERT INTO Asignacion (id,  estado_curso, nota_curso, realizacion_retiro, id_estudiante, id_curso)  
VALUES (193, 'Pendiente', 0.00, 'Pendiente', 20210104,64);

INSERT INTO Asignacion (id,  estado_curso, nota_curso, realizacion_retiro, id_estudiante, id_curso)  
VALUES (194, 'Pendiente', 0.00, 'Pendiente', 20210003,64);

INSERT INTO Asignacion (id,  estado_curso, nota_curso, realizacion_retiro, id_estudiante, id_curso)  
VALUES (195, 'Pendiente', 0.00, 'Pendiente', 20210030,64);

INSERT INTO Asignacion (id,  estado_curso, nota_curso, realizacion_retiro, id_estudiante, id_curso)  
VALUES (196, 'Pendiente', 0.00, 'Pendiente', 20210104,65);

INSERT INTO Asignacion (id,  estado_curso, nota_curso, realizacion_retiro, id_estudiante, id_curso)  
VALUES (197, 'Pendiente', 0.00, 'Pendiente', 20210003,65);

INSERT INTO Asignacion (id,  estado_curso, nota_curso, realizacion_retiro, id_estudiante, id_curso)  
VALUES (198, 'Pendiente', 0.00, 'Pendiente', 20210030,65);

select * from asignacion 
    order by id desc;

INSERT INTO Asignacion (id,  estado_curso, nota_curso, realizacion_retiro, id_estudiante, id_curso)  
VALUES (88, 'Pendiente', 0, 'Pendiente', 20210104,30);

INSERT INTO Asignacion (id,  estado_curso, nota_curso, realizacion_retiro, id_estudiante, id_curso)  
VALUES (89, 'Pendiente', 0.00, 'Pendiente', 20210003,30);

INSERT INTO Asignacion (id,  estado_curso, nota_curso, realizacion_retiro, id_estudiante, id_curso)  
VALUES (90, 'Pendiente', 0.00, 'Pendiente', 20210030,30);

INSERT INTO Asignacion (id,  estado_curso, nota_curso, realizacion_retiro, id_estudiante, id_curso)  
VALUES (91, 'En Proceso', 0.00, 'Realizado', 20210104,31);

INSERT INTO Asignacion (id,  estado_curso, nota_curso, realizacion_retiro, id_estudiante, id_curso)  
VALUES (92, 'Pendiente', 0.00, 'Pendiente', 20210003,31);

INSERT INTO Asignacion (id,  estado_curso, nota_curso, realizacion_retiro, id_estudiante, id_curso)  
VALUES (93, 'Pendiente', 0.00, 'Pendiente', 20210030,31);

INSERT INTO Asignacion (id,  estado_curso, nota_curso, realizacion_retiro, id_estudiante, id_curso)  
VALUES (94, 'Pendiente', 0.00, 'Pendiente', 20210104,32);

INSERT INTO Asignacion (id,  estado_curso, nota_curso, realizacion_retiro, id_estudiante, id_curso)  
VALUES (95, 'Pendiente', 0.00, 'Pendiente', 20210003,32);

INSERT INTO Asignacion (id,  estado_curso, nota_curso, realizacion_retiro, id_estudiante, id_curso)  
VALUES (96, 'Pendiente', 0.00, 'Pendiente', 20210030,32);

INSERT INTO Asignacion (id,  estado_curso, nota_curso, realizacion_retiro, id_estudiante, id_curso)  
VALUES (97, 'Pendiente', 0.00, 'Pendiente', 20210104,33);

INSERT INTO Asignacion (id,  estado_curso, nota_curso, realizacion_retiro, id_estudiante, id_curso)  
VALUES (98, 'Pendiente', 0.00, 'Pendiente', 20210003,33);

INSERT INTO Asignacion (id,  estado_curso, nota_curso, realizacion_retiro, id_estudiante, id_curso)  
VALUES (99, 'Pendiente', 0.00, 'Pendiente', 20210030,33);

INSERT INTO Asignacion (id,  estado_curso, nota_curso, realizacion_retiro, id_estudiante, id_curso)  
VALUES (100, 'Pendiente', 0.00, 'Pendiente', 20210104,34);

INSERT INTO Asignacion (id,  estado_curso, nota_curso, realizacion_retiro, id_estudiante, id_curso)  
VALUES (101, 'Pendiente', 0.00, 'Pendiente', 20210003,34);

INSERT INTO Asignacion (id,  estado_curso, nota_curso, realizacion_retiro, id_estudiante, id_curso)  
VALUES (102, 'Pendiente', 0.00, 'Pendiente', 20210030,34);

INSERT INTO Asignacion (id,  estado_curso, nota_curso, realizacion_retiro, id_estudiante, id_curso)  
VALUES (103, 'Pendiente', 0.00, 'Pendiente', 20210104,35);

INSERT INTO Asignacion (id,  estado_curso, nota_curso, realizacion_retiro, id_estudiante, id_curso)  
VALUES (104, 'Pendiente', 0.00, 'Pendiente', 20210003,35);

INSERT INTO Asignacion (id,  estado_curso, nota_curso, realizacion_retiro, id_estudiante, id_curso)  
VALUES (105, 'Pendiente', 0.00, 'Pendiente', 20210030,35);

INSERT INTO Asignacion (id,  estado_curso, nota_curso, realizacion_retiro, id_estudiante, id_curso)  
VALUES (106, 'Aprovado', 90.00, 'Realizado', 20210104,36);

INSERT INTO Asignacion (id,  estado_curso, nota_curso, realizacion_retiro, id_estudiante, id_curso)  
VALUES (107, 'Aprovado', 90.00, 'Realizado', 20210003,36);

INSERT INTO Asignacion (id,  estado_curso, nota_curso, realizacion_retiro, id_estudiante, id_curso)  
VALUES (108, 'Aprovado', 90.00, 'Realizado', 20210030,36);

INSERT INTO Asignacion (id,  estado_curso, nota_curso, realizacion_retiro, id_estudiante, id_curso)  
VALUES (109, 'Aprovado', 62.00, 'Realizado', 20210104,37);

INSERT INTO Asignacion (id,  estado_curso, nota_curso, realizacion_retiro, id_estudiante, id_curso)  
VALUES (110, 'Aprovado', 90.00, 'Realizado', 20210003,37);

INSERT INTO Asignacion (id,  estado_curso, nota_curso, realizacion_retiro, id_estudiante, id_curso)  
VALUES (111, 'Aprovado', 100.00, 'Realizado', 20210030,37);

INSERT INTO Asignacion (id,  estado_curso, nota_curso, realizacion_retiro, id_estudiante, id_curso)  
VALUES (112, 'Aprovado', 100.00, 'Realizado', 20210104,38);

INSERT INTO Asignacion (id,  estado_curso, nota_curso, realizacion_retiro, id_estudiante, id_curso)  
VALUES (113, 'Aprovado', 100.00, 'Realizado', 20210003,38);

INSERT INTO Asignacion (id,  estado_curso, nota_curso, realizacion_retiro, id_estudiante, id_curso)  
VALUES (114, 'Aprovado', 100.00, 'Realizado', 20210030,38);

INSERT INTO Asignacion (id,  estado_curso, nota_curso, realizacion_retiro, id_estudiante, id_curso)  
VALUES (115, 'Aprovado', 88.00, 'Realizado', 20210104,39);

INSERT INTO Asignacion (id,  estado_curso, nota_curso, realizacion_retiro, id_estudiante, id_curso)  
VALUES (116, 'Aprovado', 76.00, 'Realizado', 20210003,39);

INSERT INTO Asignacion (id,  estado_curso, nota_curso, realizacion_retiro, id_estudiante, id_curso)  
VALUES (117, 'Aprovado', 85.00, 'Realizado', 20210030,39);

INSERT INTO Asignacion (id,  estado_curso, nota_curso, realizacion_retiro, id_estudiante, id_curso)  
VALUES (118, 'Aprovado', 91.00, 'Realizado', 20210104,40);

INSERT INTO Asignacion (id,  estado_curso, nota_curso, realizacion_retiro, id_estudiante, id_curso)  
VALUES (119, 'Aprovado', 83.00, 'Realizado', 20210003,40);

INSERT INTO Asignacion (id,  estado_curso, nota_curso, realizacion_retiro, id_estudiante, id_curso)  
VALUES (120, 'Aprovado', 89.00, 'Realizado', 20210030,40);

INSERT INTO Asignacion (id,  estado_curso, nota_curso, realizacion_retiro, id_estudiante, id_curso)  
VALUES (121, 'Aprovado', 95.00, 'Realizado', 20210104,41);

INSERT INTO Asignacion (id,  estado_curso, nota_curso, realizacion_retiro, id_estudiante, id_curso)  
VALUES (122, 'Aprovado', 93.00, 'Realizado', 20210003,41);

INSERT INTO Asignacion (id,  estado_curso, nota_curso, realizacion_retiro, id_estudiante, id_curso)  
VALUES (123, 'Aprovado', 97.00, 'Realizado', 20210030,41);

INSERT INTO Asignacion (id,  estado_curso, nota_curso, realizacion_retiro, id_estudiante, id_curso)  
VALUES (124, 'Aprovado', 81.00, 'Realizado', 20210104,42);

INSERT INTO Asignacion (id,  estado_curso, nota_curso, realizacion_retiro, id_estudiante, id_curso)  
VALUES (125, 'Aprovado', 85.00, 'Realizado', 20210003,42);

INSERT INTO Asignacion (id,  estado_curso, nota_curso, realizacion_retiro, id_estudiante, id_curso)  
VALUES (126, 'Aprovado', 87.00, 'Realizado', 20210030,42);

INSERT INTO Asignacion (id,  estado_curso, nota_curso, realizacion_retiro, id_estudiante, id_curso)  
VALUES (127, 'Aprovado', 90.00, 'Realizado', 20210104,43);

INSERT INTO Asignacion (id,  estado_curso, nota_curso, realizacion_retiro, id_estudiante, id_curso)  
VALUES (128, 'Aprovado', 89.00, 'Realizado', 20210003,43);

INSERT INTO Asignacion (id,  estado_curso, nota_curso, realizacion_retiro, id_estudiante, id_curso)  
VALUES (129, 'Aprovado', 91.00, 'Realizado', 20210030,43);

INSERT INTO Asignacion (id,  estado_curso, nota_curso, realizacion_retiro, id_estudiante, id_curso)  
VALUES (46, 'Aprovado', 80.00, 'Realizado', 20210104,16);

INSERT INTO Asignacion (id,  estado_curso, nota_curso, realizacion_retiro, id_estudiante, id_curso)  
VALUES (47, 'Aprovado', 95.00, 'Realizado', 20210003,16);

INSERT INTO Asignacion (id,  estado_curso, nota_curso, realizacion_retiro, id_estudiante, id_curso)  
VALUES (48, 'Aprovado', 80.00, 'Realizado', 20210030,16);

INSERT INTO Asignacion (id,  estado_curso, nota_curso, realizacion_retiro, id_estudiante, id_curso)  
VALUES (49, 'Aprovado', 90.00, 'Realizado', 20210104,17);

INSERT INTO Asignacion (id,  estado_curso, nota_curso, realizacion_retiro, id_estudiante, id_curso)  
VALUES (50, 'Aprovado', 70.00, 'Realizado', 20210003,17);

INSERT INTO Asignacion (id,  estado_curso, nota_curso, realizacion_retiro, id_estudiante, id_curso)  
VALUES (51, 'Aprovado', 90.00, 'Realizado', 20210030,17);

INSERT INTO Asignacion (id,  estado_curso, nota_curso, realizacion_retiro, id_estudiante, id_curso)  
VALUES (52, 'Pendiente', 0.00, 'Pendiente', 20210104,18);

INSERT INTO Asignacion (id,  estado_curso, nota_curso, realizacion_retiro, id_estudiante, id_curso)  
VALUES (53, 'Pendiente', 0.00, 'Pendiente', 20210003,18);

INSERT INTO Asignacion (id,  estado_curso, nota_curso, realizacion_retiro, id_estudiante, id_curso)  
VALUES (54, 'Pendiente', 0.00, 'Pendiente', 20210030,18);

INSERT INTO Asignacion (id,  estado_curso, nota_curso, realizacion_retiro, id_estudiante, id_curso)  
VALUES (55, 'Pendiente', 0.00, 'Pendiente', 20210104,19);

INSERT INTO Asignacion (id,  estado_curso, nota_curso, realizacion_retiro, id_estudiante, id_curso)  
VALUES (56, 'Pendiente', 0.00, 'Pendiente', 20210003,19);

INSERT INTO Asignacion (id,  estado_curso, nota_curso, realizacion_retiro, id_estudiante, id_curso)  
VALUES (57, 'Pendiente', 0.00, 'Pendiente', 20210030,19);

INSERT INTO Asignacion (id,  estado_curso, nota_curso, realizacion_retiro, id_estudiante, id_curso)  
VALUES (58, 'Pendiente', 0.00, 'Pendiente', 20210104,20);

INSERT INTO Asignacion (id,  estado_curso, nota_curso, realizacion_retiro, id_estudiante, id_curso)  
VALUES (59, 'Pendiente', 0.00, 'Pendiente', 20210003,20);

INSERT INTO Asignacion (id,  estado_curso, nota_curso, realizacion_retiro, id_estudiante, id_curso)  
VALUES (60, 'Pendiente', 0.00, 'Pendiente', 20210030,20);

INSERT INTO Asignacion (id,  estado_curso, nota_curso, realizacion_retiro, id_estudiante, id_curso)  
VALUES (61, 'Pendiente', 0.00, 'Pendiente', 20210104,21);

INSERT INTO Asignacion (id,  estado_curso, nota_curso, realizacion_retiro, id_estudiante, id_curso)  
VALUES (62, 'Pendiente', 00.00, 'Pendiente', 20210003,21);

INSERT INTO Asignacion (id,  estado_curso, nota_curso, realizacion_retiro, id_estudiante, id_curso)  
VALUES (63, 'Pendiente', 0.00, 'Pendiente', 20210030,21);

INSERT INTO Asignacion (id,  estado_curso, nota_curso, realizacion_retiro, id_estudiante, id_curso)  
VALUES (64, 'Pendiente', 0.00, 'Pendiente', 20210104,22);

INSERT INTO Asignacion (id,  estado_curso, nota_curso, realizacion_retiro, id_estudiante, id_curso)  
VALUES (65, 'Pendiente', 90.00, 'Pendiente', 20210003,22);

INSERT INTO Asignacion (id,  estado_curso, nota_curso, realizacion_retiro, id_estudiante, id_curso)  
VALUES (66, 'Pendiente', 90.00, 'Pendiente', 20210030,22);

INSERT INTO Asignacion (id,  estado_curso, nota_curso, realizacion_retiro, id_estudiante, id_curso)  
VALUES (67, 'Pendiente', 0.00, 'Pendiente', 20210104,23);

INSERT INTO Asignacion (id,  estado_curso, nota_curso, realizacion_retiro, id_estudiante, id_curso)  
VALUES (68, 'Pendiente', 0.00, 'Pendiente', 20210003,23);

INSERT INTO Asignacion (id,  estado_curso, nota_curso, realizacion_retiro, id_estudiante, id_curso)  
VALUES (69, 'Pendiente', 0.00, 'Pendiente', 20210030,23);

INSERT INTO Asignacion (id,  estado_curso, nota_curso, realizacion_retiro, id_estudiante, id_curso)  
VALUES (70, 'Pendiente', 0.00, 'Pendiente', 20210104,24);

INSERT INTO Asignacion (id,  estado_curso, nota_curso, realizacion_retiro, id_estudiante, id_curso)  
VALUES (71, 'Pendiente', 0.00, 'Pendiente', 20210003,24);

INSERT INTO Asignacion (id,  estado_curso, nota_curso, realizacion_retiro, id_estudiante, id_curso)  
VALUES (72, 'Pendiente', 0.00, 'Pendiente', 20210030,24);

INSERT INTO Asignacion (id,  estado_curso, nota_curso, realizacion_retiro, id_estudiante, id_curso)  
VALUES (73, 'Pendiente', 0.00, 'Pendiente', 20210104,25);

INSERT INTO Asignacion (id,  estado_curso, nota_curso, realizacion_retiro, id_estudiante, id_curso)  
VALUES (74, 'Pendiente', 0.00, 'Pendiente', 20210003,25);

INSERT INTO Asignacion (id,  estado_curso, nota_curso, realizacion_retiro, id_estudiante, id_curso)  
VALUES (75, 'Pendiente', 0.00, 'Pendiente', 20210030,25);

INSERT INTO Asignacion (id,  estado_curso, nota_curso, realizacion_retiro, id_estudiante, id_curso)  
VALUES (76, 'Pendiente', 0.00, 'Pendiente', 20210104,26);

INSERT INTO Asignacion (id,  estado_curso, nota_curso, realizacion_retiro, id_estudiante, id_curso)  
VALUES (77, 'Pendiente', 0.00, 'Pendiente', 20210003,26);

INSERT INTO Asignacion (id,  estado_curso, nota_curso, realizacion_retiro, id_estudiante, id_curso)  
VALUES (78, 'Pendiente', 0.00, 'Pendiente', 20210030,26);

INSERT INTO Asignacion (id,  estado_curso, nota_curso, realizacion_retiro, id_estudiante, id_curso)  
VALUES (79, 'Aprobado', 80.00, 'Realizado', 20210104,27);

INSERT INTO Asignacion (id,  estado_curso, nota_curso, realizacion_retiro, id_estudiante, id_curso)  
VALUES (80, 'Aprobado', 90.00, 'Realizado', 20210003,27);

INSERT INTO Asignacion (id,  estado_curso, nota_curso, realizacion_retiro, id_estudiante, id_curso)  
VALUES (81, 'Aprobado', 80.00, 'Realizado', 20210030,27);

INSERT INTO Asignacion (id,  estado_curso, nota_curso, realizacion_retiro, id_estudiante, id_curso)  
VALUES (82, 'Pendiente', 0.00, 'Pendiente', 20210104,28);

INSERT INTO Asignacion (id,  estado_curso, nota_curso, realizacion_retiro, id_estudiante, id_curso)  
VALUES (83, 'Pendiente', 0.00, 'Pendiente', 20210003,28);

INSERT INTO Asignacion (id,  estado_curso, nota_curso, realizacion_retiro, id_estudiante, id_curso)  
VALUES (84, 'Pendiente', 0.00, 'Pendiente', 20210030,28);

INSERT INTO Asignacion (id,  estado_curso, nota_curso, realizacion_retiro, id_estudiante, id_curso)  
VALUES (85, 'Pendiente', 0.00, 'Pendiente', 20210104,29);

INSERT INTO Asignacion (id,  estado_curso, nota_curso, realizacion_retiro, id_estudiante, id_curso)  
VALUES (86, 'Pendiente', 0.00, 'Pendiente', 20210003,29);

INSERT INTO Asignacion (id,  estado_curso, nota_curso, realizacion_retiro, id_estudiante, id_curso)  
VALUES (87, 'Pendiente', 0.00, 'Pendiente', 20210030,29);

select * from asignacion 
    order by id desc;

select * from asignacion 
    where id = 130;

select * from asignacion 
     
    order by id desc;

INSERT INTO Asignacion (id,  estado_curso, nota_curso, realizacion_retiro, id_estudiante, id_curso)  
VALUES (199, 'Pendiente', 0.00, 'Pendiente', 20210104,66);

INSERT INTO Asignacion (id,  estado_curso, nota_curso, realizacion_retiro, id_estudiante, id_curso)  
VALUES (200, 'Pendiente', 0.00, 'Pendiente', 20210003,66);

INSERT INTO Asignacion (id,  estado_curso, nota_curso, realizacion_retiro, id_estudiante, id_curso)  
VALUES (201, 'Pendiente', 0.00, 'Pendiente', 20210030,66);

INSERT INTO Asignacion (id,  estado_curso, nota_curso, realizacion_retiro, id_estudiante, id_curso)  
VALUES (202, 'Pendiente', 0.00, 'Pendiente', 20210104,67);

INSERT INTO Asignacion (id,  estado_curso, nota_curso, realizacion_retiro, id_estudiante, id_curso)  
VALUES (203, 'Pendiente', 0.00, 'Pendiente', 20210003,67);

INSERT INTO Asignacion (id,  estado_curso, nota_curso, realizacion_retiro, id_estudiante, id_curso)  
VALUES (204, 'Pendiente', 0.00, 'Pendiente', 20210030,67);

INSERT INTO Asignacion (id,  estado_curso, nota_curso, realizacion_retiro, id_estudiante, id_curso)  
VALUES (205, 'Pendiente', 0.00, 'Pendiente', 20210104,68);

INSERT INTO Asignacion (id,  estado_curso, nota_curso, realizacion_retiro, id_estudiante, id_curso)  
VALUES (206, 'Pendiente', 0.00, 'Pendiente', 20210003,68);

INSERT INTO Asignacion (id,  estado_curso, nota_curso, realizacion_retiro, id_estudiante, id_curso)  
VALUES (207, 'Pendiente', 0.00, 'Pendiente', 20210030,68);

INSERT INTO Asignacion (id,  estado_curso, nota_curso, realizacion_retiro, id_estudiante, id_curso)  
VALUES (208, 'Pendiente', 0.00, 'Pendiente', 20210104,70);

INSERT INTO Asignacion (id,  estado_curso, nota_curso, realizacion_retiro, id_estudiante, id_curso)  
VALUES (209, 'Pendiente', 0.00, 'Pendiente', 20210003,70);

INSERT INTO Asignacion (id,  estado_curso, nota_curso, realizacion_retiro, id_estudiante, id_curso)  
VALUES (210, 'Pendiente', 0.00, 'Pendiente', 20210030,70);

select * from asignacion 
     
    order by id desc;

INSERT INTO Asignacion (id,  estado_curso, nota_curso, realizacion_retiro, id_estudiante, id_curso)  
VALUES (208, 'Pendiente', 0.00, 'Pendiente', 20210104,69);

INSERT INTO Asignacion (id,  estado_curso, nota_curso, realizacion_retiro, id_estudiante, id_curso)  
VALUES (209, 'Pendiente', 0.00, 'Pendiente', 20210003,69);

INSERT INTO Asignacion (id,  estado_curso, nota_curso, realizacion_retiro, id_estudiante, id_curso)  
VALUES (210, 'Pendiente', 0.00, 'Pendiente', 20210030,69);

select * from asignacion 
     
    order by id desc;

select * from curso;

select * from curso;

select * from curso 
    where creditos_teoricos = 4;

select * from curso;

select max(creditos_teoricos) from curso;

select max(creditos_teoricos) from curso;

select * from curso 
    where max(creditos_teoricos);

select max(creditos_teoricos) from curso;

select * from curso 
     
     
     
    order by id desc;

select * from curso 
    order by codigo_curso desc;

update curso 
    set creditos_teoricos = 5, creditos_practicos =5 
    where codigo_curso = 57;

select max(creditos_teoricos) from curso;

select max(creditos_teoricos) from curso;

select max(creditros_teoricos) from curso;

select max(creditos_teoricos) from curso;

select min(creditos_teoricos) from curso;

select min(creditos_teoricos), nombre_curso from curso;

select creditos_teoricos, nombre_curso from curso 
    where creditos_teoricos = (select min(creditos_teoricos)from curso);

select creditos_teoricos, nombre_curso from curso 
    where creditos_teoricos = (select max(creditos_teoricos)from curso);

INSERT INTO Carrera (codigo_carrera,  nombre, descripcion)  
VALUES (1, 'Computer Science', 'Ingenieria en ciencias de la computacion');

alter table carrera 
drop column nombre;

alter table carrera 
add nombre varchar(20);

Select * from carrera;

Select * from carrera;

Select * from carrera;

INSERT INTO Carrera (codigo_carrera,  nombre, descripcion)  
VALUES (1, 'Computer Science', 'Ingenieria en ciencias de la computacion');

Select * from carrera;

select * from curso;

select * from asignacion;

alter table curso 
add nbr_prerrequisitos INT;

update Curso  
set nbr_prerrequisitos = 0 
where codigo_curso =8;

select * from curso;

select * from curso 
order by codigo_curso;

select * from curso 
order by prerrequisitos;

select * from curso 
order by codigo_curso;

update Curso  
set nbr_prerrequisitos = 0 
where codigo_curso =9;

update Curso  
set nbr_prerrequisitos = 0 
where codigo_curso =11;

update Curso  
set nbr_prerrequisitos = 0 
where codigo_curso =11;

select * from curso 
order by codigo_curso;

update Curso  
set nbr_prerrequisitos = 0 
where codigo_curso =10;

update Curso  
set nbr_prerrequisitos = 0 
where codigo_curso =11;

select * from curso 
order by codigo_curso;

SELECT curso, seccion 
FROM ( 
  SELECT curso, seccion, AVG(nota_curso) AS promedio 
  FROM Asignacion 
  WHERE posible = 'Curso favorito del grupo' 
  GROUP BY curso, seccion 
  ORDER BY promedio DESC 
) 
FETCH FIRST 1 ROW ONLY;

select * from curso 
order by codigo_curso;

update Curso  
set nbr_prerrequisitos = 0 
where codigo_curso =12;

update Curso  
set nbr_prerrequisitos = 0 
where codigo_curso =13;

select * from curso 
order by codigo_curso;

update Curso  
set nbr_prerrequisitos = 0 
where codigo_curso =15;

update Curso  
set nbr_prerrequisitos = 0 
where codigo_curso =14;

update Curso  
set nbr_prerrequisitos = 0 
where codigo_curso =15;

update Curso  
set nbr_prerrequisitos = 0 
where codigo_curso =16;

update Curso  
set nbr_prerrequisitos = 0 
where codigo_curso =17;

select * from curso 
order by codigo_curso;

update Curso  
set nbr_prerrequisitos = 0 
where codigo_curso =25;

update Curso  
set nbr_prerrequisitos = 0 
where codigo_curso =24;

select * from curso 
order by codigo_curso;

update Curso  
set nbr_prerrequisitos = 0 
where codigo_curso =29;

update Curso  
set nbr_prerrequisitos = 0 
where codigo_curso =30;

select * from curso 
order by codigo_curso;

update Curso  
set nbr_prerrequisitos = 0 
where codigo_curso =32;

update Curso  
set nbr_prerrequisitos = 0 
where codigo_curso =33;

select * from curso 
order by codigo_curso;

update Curso  
set nbr_prerrequisitos = 0 
where codigo_curso =36;

update Curso  
set nbr_prerrequisitos = 0 
where codigo_curso =50;

select * from curso 
order by codigo_curso;

SELECT c.nombre_curso, h.seccion, AVG(a.nota_curso) AS promedio  
FROM CURSO c  
INNER JOIN Horario h ON c.codigo_curso = h.curso  
INNER JOIN Asignacion a ON a.id_curso = c.codigo_curso  
WHERE c.codigo_curso = 1234  
GROUP BY c.nombre_curso, h.seccion  
ORDER BY promedio DESC  
FETCH FIRST ROW ONLY;

SELECT c.nombre_curso, AVG(a.nota_curso) AS promedio  
FROM CURSO c  
INNER JOIN Asignacion a ON a.id_curso = c.codigo_curso  
WHERE c.codigo_curso = 1  
GROUP BY c.nombre_curso  
ORDER BY promedio DESC  
FETCH FIRST ROW ONLY;

SELECT c.nombre_curso, AVG(a.nota_curso) AS promedio  
FROM CURSO c  
INNER JOIN Asignacion a ON a.id_curso = c.codigo_curso  
WHERE c.codigo_curso = 5  
GROUP BY c.nombre_curso  
ORDER BY promedio DESC  
FETCH FIRST ROW ONLY;

SELECT c.nombre_curso, AVG(a.nota_curso) AS promedio  
FROM CURSO c  
INNER JOIN Asignacion a ON a.id_curso = c.codigo_curso  
WHERE c.codigo_curso = 8  
GROUP BY c.nombre_curso  
ORDER BY promedio DESC  
FETCH FIRST ROW ONLY;

SELECT c.nombre_curso, AVG(a.nota_curso) AS promedio  
FROM CURSO c  
INNER JOIN Asignacion a ON a.id_curso = c.codigo_curso  
WHERE c.codigo_curso = 9  
GROUP BY c.nombre_curso  
ORDER BY promedio DESC  
FETCH FIRST ROW ONLY;

SELECT c.nombre_curso, AVG(a.nota_curso) AS promedio  
FROM CURSO c  
INNER JOIN Asignacion a ON a.id_curso = c.codigo_curso  
WHERE c.codigo_curso = 1  
GROUP BY c.nombre_curso  
ORDER BY promedio DESC  
FETCH FIRST ROW ONLY;

select * from asignacion 
    where id_curso = 1;

SELECT c.nombre_curso, AVG(a.nota_curso) AS promedio  
FROM CURSO c  
INNER JOIN Asignacion a ON a.id_curso = c.codigo_curso  
WHERE c.codigo_curso = 45  
GROUP BY c.nombre_curso  
ORDER BY promedio DESC  
FETCH FIRST ROW ONLY;

select * from asignacion 
    where id_curso = 45;

SELECT c.nombre_curso, AVG(a.nota_curso) AS promedio  
FROM Estudiantes e  
INNER JOIN Asignacion a ON a.id_estudiante = e.carnet  
INNER JOIN CURSO c ON a.id_curso = c.codigo_curso  
GROUP BY c.nombre_curso  
ORDER BY promedio DESC  
FETCH FIRST ROW ONLY;

select * from curso 
    where nombre_curso = 'Intro a Filosofia' 
order by codigo_curso;

SELECT c.nombre_curso, AVG(a.nota_curso) AS promedio  
FROM Estudiantes e  
INNER JOIN Asignacion a ON a.id_estudiante = e.carnet  
INNER JOIN CURSO c ON a.id_curso = c.codigo_curso  
GROUP BY c.nombre_curso  
ORDER BY promedio DESC  
FETCH FIRST ROW ONLY;

select * from curso 
    where nombre_curso = 'Intro a la Filosofia' 
order by codigo_curso;

select * from asignacion 
    where nombre = 38;

select * from asignacion 
    where id_curso = 38;

SELECT c.nombre_curso, AVG(a.nota_curso) AS promedio  
FROM Estudiantes e  
INNER JOIN Asignacion a ON a.id_estudiante = e.carnet  
INNER JOIN CURSO c ON a.id_curso = c.codigo_curso  
GROUP BY c.nombre_curso  
ORDER BY promedio DESC  
FETCH FIRST ROW ONLY;

select * from curso 
order by codigo_curso;

update Curso  
set nbr_prerrequisitos = 4 
where codigo_curso =1;

select * from curso 
order by codigo_curso;

update Curso  
set nbr_prerrequisitos = 2 
where codigo_curso =2;

select * from curso 
order by codigo_curso;

update Curso  
set nbr_prerrequisitos = 7 
where codigo_curso =3;

select * from curso 
order by codigo_curso;

select * from curso 
order by codigo_curso;

update Curso  
set nbr_prerrequisitos = 6 
where codigo_curso =4;

update Curso  
set nbr_prerrequisitos = 4 
where codigo_curso =6;

select * from curso 
order by codigo_curso;

select * from curso 
order by codigo_curso;

update Curso  
set nbr_prerrequisitos = 3 
where codigo_curso =5;

select * from curso 
order by codigo_curso;

update Curso  
set nbr_prerrequisitos = 4 
where codigo_curso =6;

select * from curso 
order by codigo_curso;

update Curso  
set nbr_prerrequisitos = 3 
where codigo_curso =7;

select * from curso 
order by codigo_curso;

SELECT c.nombre_curso, AVG(a.nota_curso) AS promedio  
FROM Estudiantes e  
INNER JOIN Asignacion a ON a.id_estudiante = e.carnet  
INNER JOIN CURSO c ON a.id_curso = c.codigo_curso  
GROUP BY c.nombre_curso  
ORDER BY promedio DESC  
FETCH FIRST ROW ONLY;

select * from curso 
order by codigo_curso;

SELECT c.nombre_curso, AVG(a.nota_curso) AS promedio  
FROM Estudiantes e  
INNER JOIN Asignacion a ON a.id_estudiante = e.carnet  
INNER JOIN CURSO c ON a.id_curso = c.codigo_curso  
GROUP BY c.nombre_curso  
ORDER BY promedio DESC  
FETCH FIRST ROW ONLY;

SELECT  
  CASE  
    WHEN hora_inicio >= '07:00:00' AND hora_fin <= '14:00:00' THEN 'Matutina' 
    WHEN hora_inicio >= '14:00:00' AND hora_fin <= '18:00:00' THEN 'Vespertina' 
    WHEN hora_inicio >= '18:00:00' OR hora_fin <= '07:00:00' THEN 'Nocturna' 
  END AS jornada,  
  COUNT(*) AS cantidad_cursos  
FROM  
  CURSO c  
  INNER JOIN Horario h ON c.codigo_curso = h.curso  
WHERE  
  h.dias LIKE '%2%' AND h.seccion = '02' AND h.ano = 2022 AND h.ciclo = 2 AND c.descripcion LIKE '%Ingeniería en Informática y Sistemas%'  
GROUP BY  
  CASE  
    WHEN hora_inicio >= '07:00:00' AND hora_fin <= '14:00:00' THEN 'Matutina' 
    WHEN hora_inicio >= '14:00:00' AND hora_fin <= '18:00:00' THEN 'Vespertina' 
    WHEN hora_inicio >= '18:00:00' OR hora_fin <= '07:00:00' THEN 'Nocturna' 
  END  
ORDER BY  
  cantidad_cursos DESC  
FETCH FIRST ROW ONLY;

select * from curso 
order by codigo_curso;

update Curso  
set nbr_prerrequisitos = 5 
where codigo_curso =18;

select * from curso 
order by codigo_curso;

Alter table asignacion 
add semestre int;

select * from curso 
order by codigo_curso;

update Curso  
set nbr_prerrequisitos = 2 
where codigo_curso =19;

select * from curso 
order by codigo_curso;

update Curso  
set nbr_prerrequisitos = 3 
where codigo_curso =20;

update Curso  
set nbr_prerrequisitos = 4 
where codigo_curso =21;

select * from curso 
order by codigo_curso;

INSERT INTO Asignacion (semestre)  
VALUES (1) 
WHERE codigo_curso = 11;

update Asignacion  
set semestre =1 
WHERE codigo_curso = 11;

update Asignacion  
set semestre =1 
WHERE id_curso = 11;

select * from asignacion 
order by id_curso;

select * from asignacion 
order by id;

select * from curso 
    where codigo_curso =11 
order by codigo_curso;

select * from asignacion 
order by id;

select * from curso 
order by codigo_curso;

update Curso  
set nbr_prerrequisitos = 3 
where codigo_curso =23;

update Curso  
set nbr_prerrequisitos = 3 
where codigo_curso =23;

update Curso  
set nbr_prerrequisitos = 4 
where codigo_curso =22;

select * from curso 
order by codigo_curso;

update Curso  
set nbr_prerrequisitos = 3 
where codigo_curso =23;

select * from curso 
order by codigo_curso;

update Curso  
set nbr_prerrequisitos = 2 
where codigo_curso =26;

update Curso  
set nbr_prerrequisitos = 2 
where codigo_curso =28;

select * from curso 
order by codigo_curso;

update Curso  
set nbr_prerrequisitos = 1 
where codigo_curso =27;

select * from curso 
order by codigo_curso;

select * from curso 
order by codigo_curso;

update Curso  
set nbr_prerrequisitos = 6 
where codigo_curso =31;

select * from curso 
order by codigo_curso;

update Curso  
set nbr_prerrequisitos = 4 
where codigo_curso =34;

select * from curso 
order by codigo_curso;

update Curso  
set nbr_prerrequisitos = 5 
where codigo_curso =35;

select * from curso 
order by codigo_curso;

select * from curso 
order by codigo_curso;

update Curso  
set nbr_prerrequisitos = 1 
where codigo_curso =37;

select * from curso 
order by codigo_curso;

update Curso  
set nbr_prerrequisitos = 1 
where codigo_curso =38;

update Curso  
set nbr_prerrequisitos = 1 
where codigo_curso =39;

select * from curso 
order by codigo_curso;

select * from curso 
    where nombre_curso ='Algebra Lineal' 
order by codigo_curso;

select * from curso 
order by codigo_curso;

update Curso  
set nbr_prerrequisitos = 1 
where codigo_curso =40;

update Curso  
set nbr_prerrequisitos = 1 
where codigo_curso =40;

update Curso  
set nbr_prerrequisitos = 1 
where codigo_curso =41;

update Curso  
set nbr_prerrequisitos = 1 
where codigo_curso =40;

select * from curso 
order by codigo_curso;

pdate Curso  


set nbr_prerrequisitos = 1 


where codigo_curso =42;


update Curso  
set nbr_prerrequisitos = 1 
where codigo_curso =43;

update Curso  
set nbr_prerrequisitos = 1 
where codigo_curso =42;

update Curso  
set nbr_prerrequisitos = 1 
where codigo_curso =43;

select * from curso 
order by codigo_curso;

update Curso  
set nbr_prerrequisitos = 2 
where codigo_curso =44;

update Curso  
set nbr_prerrequisitos = 2 
where codigo_curso =45;

select * from curso 
order by codigo_curso;

update Curso  
set nbr_prerrequisitos = 2 
where codigo_curso =46;

update Curso  
set nbr_prerrequisitos = 4 
where codigo_curso =47;

select * from curso 
order by codigo_curso;

update Curso  
set nbr_prerrequisitos = 2 
where codigo_curso =48;

update Curso  
set nbr_prerrequisitos = 1 
where codigo_curso =49;

select * from curso 
order by codigo_curso;

update Asignacion  
set semestre =3 
WHERE id_curso = 43;

update Asignacion  
set semestre =3 
WHERE id_curso = 44;

update Asignacion  
set semestre =3 
WHERE id_curso = 45;

update Asignacion  
set semestre =3 
WHERE id_curso = 46;

update Asignacion  
set semestre =3 
WHERE id_curso = 47;

update Asignacion  
set semestre =3 
WHERE id_curso = 48;

update Asignacion  
set semestre =3 
WHERE id_curso = 49;

update Asignacion  
set semestre =3 
WHERE id_curso = 50;

select * from asignacion 
order by id;

select * from asignacion 
order by semestre;

update Asignacion  
set semestre =1 
WHERE id_curso = 11;

update Asignacion  
set semestre = 4 
WHERE id_curso = 63;

update Asignacion  
set semestre = 4 
WHERE id_curso = 51;

update Asignacion  
set semestre = 4 
WHERE id_curso = 62;

update Asignacion  
set semestre = 4 
WHERE id_curso = 64;

update Asignacion  
set semestre = 4 
WHERE id_curso = 53;

update Asignacion  
set semestre = 4 
WHERE id_curso = 52;

update Asignacion  
set semestre = 4 
WHERE id_curso = 65;

update Asignacion  
set semestre = 4 
WHERE id_curso = 66;

update Asignacion  
set semestre = 4 
WHERE id_curso = 67;

select * from asignacion 
order by semestre;

update Asignacion  
set semestre =1 
WHERE id_curso = 11;

update Asignacion  
set semestre = 4 
WHERE id_curso = 63;

update Asignacion  
set semestre = 4 
WHERE id_curso = 51;

update Asignacion  
set semestre = 4 
WHERE id_curso = 62;

update Asignacion  
set semestre = 4 
WHERE id_curso = 64;

update Asignacion  
set semestre = 4 
WHERE id_curso = 53;

update Asignacion  
set semestre = 4 
WHERE id_curso = 52;

update Asignacion  
set semestre = 4 
WHERE id_curso = 65;

update Asignacion  
set semestre = 4 
WHERE id_curso = 66;

update Asignacion  
set semestre = 4 
WHERE id_curso = 67;

select * from asignacion 
    where id_curso =52 
order by semestre;

select * from curso 
    where codigo_curso =52 
order by codigo_curso;

select * from asignacion 
    where id_curso =52 
order by semestre;

SELECT COUNT(*) AS num_cursos,  
  CASE  
    WHEN hora_inicio < TO_DATE('14:00', 'HH24:MI') THEN 'Matutina'  
    WHEN hora_inicio < TO_DATE('18:00', 'HH24:MI') THEN 'Vespertina'  
    ELSE 'Nocturna'  
  END AS jornada  
FROM Asignacion  
JOIN Horario ON Asignacion.id = Horario.id  
WHERE Asignacion.semestre = 5  
GROUP BY  
  CASE  
    WHEN hora_inicio < TO_DATE('14:00', 'HH24:MI') THEN 'Matutina'  
    WHEN hora_inicio < TO_DATE('18:00', 'HH24:MI') THEN 'Vespertina'  
    ELSE 'Nocturna'  
  END;

SELECT COUNT(*) AS num_cursos,  
  CASE  
    WHEN hora_inicio < TO_DATE('14:00', 'HH24:MI') THEN 'Matutina'  
    WHEN hora_inicio < TO_DATE('18:00', 'HH24:MI') THEN 'Vespertina'  
    ELSE 'Nocturna'  
  END AS jornada  
FROM Asignacion  
JOIN Horario ON Asignacion.id = Horario.id  
WHERE Asignacion.semestre = 4 
GROUP BY  
  CASE  
    WHEN hora_inicio < TO_DATE('14:00', 'HH24:MI') THEN 'Matutina'  
    WHEN hora_inicio < TO_DATE('18:00', 'HH24:MI') THEN 'Vespertina'  
    ELSE 'Nocturna'  
  END;

SELECT COUNT(*) AS num_cursos,  
  CASE  
    WHEN hora_inicio < TO_DATE('14:00', 'HH24:MI') THEN 'Matutina'  
    WHEN hora_inicio < TO_DATE('18:00', 'HH24:MI') THEN 'Vespertina'  
    ELSE 'Nocturna'  
  END AS jornada  
FROM Asignacion  
JOIN Horario ON Asignacion.id = Horario.id  
WHERE Asignacion.semestre = 3 
GROUP BY  
  CASE  
    WHEN hora_inicio < TO_DATE('14:00', 'HH24:MI') THEN 'Matutina'  
    WHEN hora_inicio < TO_DATE('18:00', 'HH24:MI') THEN 'Vespertina'  
    ELSE 'Nocturna'  
  END;

SELECT COUNT(*) AS num_cursos,  
  CASE  
    WHEN hora_inicio < TO_DATE('14:00', 'HH24:MI') THEN 'Matutina'  
    WHEN hora_inicio < TO_DATE('18:00', 'HH24:MI') THEN 'Vespertina'  
    ELSE 'Nocturna'  
  END AS jornada  
FROM Asignacion a JOIN Horario h ON a.id = h.id  
WHERE a.semestre = 3 
GROUP BY  
  CASE  
    WHEN hora_inicio < TO_DATE('14:00', 'HH24:MI') THEN 'Matutina'  
    WHEN hora_inicio < TO_DATE('18:00', 'HH24:MI') THEN 'Vespertina'  
    ELSE 'Nocturna'  
  END;

SELECT COUNT(*) AS num_cursos,  
  CASE  
    WHEN hora_inicio < TO_DATE('14:00', 'HH24:MI') THEN 'Matutina'  
    WHEN hora_inicio < TO_DATE('18:00', 'HH24:MI') THEN 'Vespertina'  
    ELSE 'Nocturna'  
  END AS jornada  
FROM Asignacion a JOIN Horario h ON a.id = h.id  
WHERE a.semestre = 1 
GROUP BY  
  CASE  
    WHEN hora_inicio < TO_DATE('14:00', 'HH24:MI') THEN 'Matutina'  
    WHEN hora_inicio < TO_DATE('18:00', 'HH24:MI') THEN 'Vespertina'  
    ELSE 'Nocturna'  
  END;

SELECT COUNT(*) AS num_cursos,  
  CASE  
    WHEN hora_inicio < TO_DATE('14:00', 'HH24:MI') THEN 'Matutina'  
    WHEN hora_inicio < TO_DATE('18:00', 'HH24:MI') THEN 'Vespertina'  
    ELSE 'Nocturna'  
  END AS jornada  
FROM Asignacion a JOIN Horario h ON a.id = h.id  
WHERE a.semestre = 1;

select * from horario 
group by id;

select * from horario 
order by id;

SELECT  
  CASE  
    WHEN hora_inicio >= TO_DATE('07:00:00', 'HH24:MI:SS') AND hora_fin <= TO_DATE('14:00:00', 'HH24:MI:SS') THEN 'Jornada matutina' 
    WHEN hora_inicio >= TO_DATE('14:00:00', 'HH24:MI:SS') AND hora_fin <= TO_DATE('18:00:00', 'HH24:MI:SS') THEN 'Jornada vespertina' 
    WHEN hora_inicio >= TO_DATE('18:00:00', 'HH24:MI:SS') THEN 'Jornada nocturna' 
  END AS jornada, 
  COUNT(*) AS cantidad_de_cursos 
FROM  
  Asignacion a  
  JOIN Horario h ON a.id_curso = h.curso 
WHERE  
  a.semestre = 5 
GROUP BY  
  CASE  
    WHEN hora_inicio >= TO_DATE('07:00:00', 'HH24:MI:SS') AND hora_fin <= TO_DATE('14:00:00', 'HH24:MI:SS') THEN 'Jornada matutina' 
    WHEN hora_inicio >= TO_DATE('14:00:00', 'HH24:MI:SS') AND hora_fin <= TO_DATE('18:00:00', 'HH24:MI:SS') THEN 'Jornada vespertina' 
    WHEN hora_inicio >= TO_DATE('18:00:00', 'HH24:MI:SS') THEN 'Jornada nocturna' 
  END 
ORDER BY  
  COUNT(*) DESC;

alter table horario 
drop column hora_inicio;

alter table horario 
drop  hora_inicio date;

alter table horario 
add hora_inicio date;

select * from horario;

select * from horario 
order by id;

select * from horario 
order by id;

INSERT INTO HORARIO (id, curso, salon, edificio, dias,  hora_fin, costo, hora_inicio) 
VALUES (10, 'Algebra Lineal' , 'EN-504', 'Escuela de Negocios', 'Martes y Jueves', '09:50', 9000, to_date('08:30:00', 'HH24:MI:SS')) 
INSERT INTO HORARIO (id, curso, salon, edificio, dias,  hora_fin, costo,hora_inicio) 
VALUES (11, 'Scientific Computing' , 'EN-606', 'Escuela de Negocios', 'Lunes y Miercoles', '15:50', 9000, to_date('14:30:00', 'HH24:MI:SS')) 
INSERT INTO HORARIO (id, curso, salon, edificio, dias,  hora_fin, costo,hora_inicio) 
VALUES (12, 'Statistical Thinking 2' , 'D-504', 'Edificio Academico', 'Martes y Jueves', '12:50', 9000, to_date('11:30:00', 'HH24:MI:SS')) 
INSERT INTO HORARIO (id, curso, salon, edificio, dias,  hora_fin, costo,hora_inicio) 
VALUES (13, 'Teorias Monetarias' , 'E-507', 'Edificio Academico', 'Lunes y Miercoles', '19:50', 9000, to_date('18:30:00', 'HH24:MI:SS')) 
INSERT INTO HORARIO (id, curso, salon, edificio, dias,  hora_fin, costo,hora_inicio) 
VALUES (14, 'Administracion Financiera' , 'EN-506', 'Escuela de Negocios', 'Martes y Jueves', '11:20', 9000, to_date('10:00:00', 'HH24:MI:SS')) 
INSERT INTO HORARIO (id, curso, salon, edificio, dias,  hora_fin, costo,hora_inicio) 
VALUES (15, 'Global Management 2' , 'D-407', 'Edificio Academico', 'Lunes y Miercoles', '09:50', 9000, to_date('08:30:00', 'HH24:MI:SS')) 
INSERT INTO HORARIO (id, curso, salon, edificio, dias,  hora_fin, costo,hora_inicio) 
VALUES (16, 'Algoritmia y complejidad' , 'EN-504', 'Escuela de Negocios', 'Martes y Jueves', '20:20', 9000, to_date('19:00:00', 'HH24:MI:SS')) 
INSERT INTO HORARIO (id, curso, salon, edificio, dias,  hora_fin, costo,hora_inicio) 
VALUES (17, 'Automation Testing' , 'D-504', 'Edificio Academico', 'Lunes', '11:20', 4500, to_date('10:00:00', 'HH24:MI:SS')) 
INSERT INTO HORARIO (id, curso, salon, edificio, dias,  hora_fin, costo,hora_inicio) 
VALUES (18, 'DevOps' , 'E-305', 'Edificio Academico', 'Jueves', '17:20', 4500, to_date('16:00:00', 'HH24:MI:SS'));

INSERT INTO HORARIO (id, curso, salon, edificio, dias,  hora_fin, costo,hora_inicio) 
VALUES (12, 'Statistical Thinking 2' , 'D-504', 'Edificio Academico', 'Martes y Jueves', '12:50', 9000, to_date('11:30:00', 'HH24:MI:SS'));

INSERT INTO HORARIO (id, curso, salon, edificio, dias,  hora_fin, costo, hora_inicio) 
VALUES (10, 'Algebra Lineal' , 'EN-504', 'Escuela de Negocios', 'Martes y Jueves', '09:50', 9000, to_date('08:30:00', 'HH24:MI:SS'));

INSERT INTO HORARIO (id, curso, salon, edificio, dias,  hora_fin, costo,hora_inicio) 
VALUES (11, 'Scientific Computing' , 'EN-606', 'Escuela de Negocios', 'Lunes y Miercoles', '15:50', 9000, to_date('14:30:00', 'HH24:MI:SS'));

INSERT INTO HORARIO (id, curso, salon, edificio, dias,  hora_fin, costo,hora_inicio) 
VALUES (12, 'Statistical Thinking 2' , 'D-504', 'Edificio Academico', 'Martes y Jueves', '12:50', 9000, to_date('11:30:00', 'HH24:MI:SS'));

INSERT INTO HORARIO (id, curso, salon, edificio, dias,  hora_fin, costo,hora_inicio) 
VALUES (13, 'Teorias Monetarias' , 'E-507', 'Edificio Academico', 'Lunes y Miercoles', '19:50', 9000, to_date('18:30:00', 'HH24:MI:SS'));

INSERT INTO HORARIO (id, curso, salon, edificio, dias,  hora_fin, costo,hora_inicio) 
VALUES (14, 'Administracion Financiera' , 'EN-506', 'Escuela de Negocios', 'Martes y Jueves', '11:20', 9000, to_date('10:00:00', 'HH24:MI:SS'));

INSERT INTO HORARIO (id, curso, salon, edificio, dias,  hora_fin, costo,hora_inicio) 
VALUES (15, 'Global Management 2' , 'D-407', 'Edificio Academico', 'Lunes y Miercoles', '09:50', 9000, to_date('08:30:00', 'HH24:MI:SS'));

INSERT INTO HORARIO (id, curso, salon, edificio, dias,  hora_fin, costo,hora_inicio) 
VALUES (15, 'Global Management 2' , 'D-407', 'Edificio Academico', 'Lunes y Miercoles', '09:50', 9000, to_date('08:30:00', 'HH24:MI:SS')) 
INSERT INTO HORARIO (id, curso, salon, edificio, dias,  hora_fin, costo,hora_inicio) 
VALUES (16, 'Algoritmia y complejidad' , 'EN-504', 'Escuela de Negocios', 'Martes y Jueves', '20:20', 9000, to_date('19:00:00', 'HH24:MI:SS'));

INSERT INTO HORARIO (id, curso, salon, edificio, dias,  hora_fin, costo,hora_inicio) 
VALUES (15, 'Global Management 2' , 'D-407', 'Edificio Academico', 'Lunes y Miercoles', '09:50', 9000, to_date('08:30:00', 'HH24:MI:SS'));

INSERT INTO HORARIO (id, curso, salon, edificio, dias,  hora_fin, costo,hora_inicio) 
VALUES (17, 'Automation Testing' , 'D-504', 'Edificio Academico', 'Lunes', '11:20', 4500, to_date('10:00:00', 'HH24:MI:SS'));

INSERT INTO HORARIO (id, curso, salon, edificio, dias,  hora_fin, costo,hora_inicio) 
VALUES (17, 'Automation Testing' , 'D-504', 'Edificio Academico', 'Lunes', '11:20', 4500, to_date('10:00:00', 'HH24:MI:SS'));

INSERT INTO HORARIO (id, curso, salon, edificio, dias,  hora_fin, costo,hora_inicio) 
VALUES (16, 'Algoritmia y complejidad' , 'EN-504', 'Escuela de Negocios', 'Martes y Jueves', '20:20', 9000, to_date('19:00:00', 'HH24:MI:SS'));

INSERT INTO HORARIO (id, curso, salon, edificio, dias,  hora_fin, costo,hora_inicio) 
VALUES (17, 'Automation Testing' , 'D-504', 'Edificio Academico', 'Lunes', '11:20', 4500, to_date('10:00:00', 'HH24:MI:SS'));

INSERT INTO HORARIO (id, curso, salon, edificio, dias,  hora_fin, costo,hora_inicio) 
VALUES (18, 'DevOps' , 'E-305', 'Edificio Academico', 'Jueves', '17:20', 4500, to_date('16:00:00', 'HH24:MI:SS'));

select * from horario 
order by id;

alter table horario 
drop column hora_inicio;

alter table horario 
add hora_inicio time;

alter table horario 
    start at time(0) 
add hora_inicio time;

alter table horario 
    start_at time(0) 
add hora_inicio time;

select * from horario 
order by id;

alter table horario 
add hora_inicio time();

alter table horario 
add hora_inicio time;

alter table horario 
add hora_inicio time(0);

alter table horario 
add hora_inicio time();

alter table horario 
add hora_inicio date;

select * from horario 
order by id;

update horario 
set hora_inicio = to_date('17:00:00', 'HH24:MI:SS') 
where id = 1;

select * from horario 
order by id;

select hora_inicio from horario 
    where id = 1 
order by id;

alter table horario 
drop column hora_inicio ;

alter table horario 
add hora_inicio date;

select hora_inicio from horario 
    where id = 1 
order by id;

select * from horario 
order by id;

update horario 
set hora_inicio = to_date('17:00:00', 'HH24:MI:SS') 
where id = 1;

select * from horario 
order by id;

SELECT EXTRACT( HOUR   FROM CAST( datetime AS TIMESTAMP ) ) AS Hours, 
       EXTRACT( MINUTE FROM CAST( datetime AS TIMESTAMP ) ) AS Minutes, 
       EXTRACT( SECOND FROM CAST( datetime AS TIMESTAMP ) ) AS Seconds 
FROM horario  
where id=1;

SELECT EXTRACT( HOUR   FROM CAST( hora_inicio AS TIMESTAMP ) ) AS Hours, 
       EXTRACT( MINUTE FROM CAST( hora_inicio AS TIMESTAMP ) ) AS Minutes, 
       EXTRACT( SECOND FROM CAST( hora_inicio AS TIMESTAMP ) ) AS Seconds 
FROM horario  
where id=1;

select * from horario 
order by id;

update horario 
set hora_inicio = to_date('08:30:00', 'HH24:MI:SS') 
where id = 10;

update horario 
set hora_inicio = to_date('14:30:00', 'HH24:MI:SS') 
where id = 11;

update horario 
set hora_inicio = to_date('11:30:00', 'HH24:MI:SS') 
where id = 12;

update horario 
set hora_inicio = to_date('18:30:00', 'HH24:MI:SS') 
where id = 13;

update horario 
set hora_inicio = to_date('10:00:00', 'HH24:MI:SS') 
where id = 14;

update horario 
set hora_inicio = to_date('08:30:00', 'HH24:MI:SS') 
where id = 15;

update horario 
set hora_inicio = to_date('19:00:00', 'HH24:MI:SS') 
where id = 16;

update horario 
set hora_inicio = to_date('10:00:00', 'HH24:MI:SS') 
where id = 17;

update horario 
set hora_inicio = to_date('16:00:00', 'HH24:MI:SS') 
where id = 18;

select * from horario 
order by id;

SELECT EXTRACT( HOUR   FROM CAST( hora_inicio AS TIMESTAMP ) ) AS Hours, 
       EXTRACT( MINUTE FROM CAST( hora_inicio AS TIMESTAMP ) ) AS Minutes, 
       EXTRACT( SECOND FROM CAST( hora_inicio AS TIMESTAMP ) ) AS Seconds 
FROM horario  
where id=10;

SELECT EXTRACT( HOUR   FROM CAST( hora_inicio AS TIMESTAMP ) ) AS Hours, 
       EXTRACT( MINUTE FROM CAST( hora_inicio AS TIMESTAMP ) ) AS Minutes, 
       EXTRACT( SECOND FROM CAST( hora_inicio AS TIMESTAMP ) ) AS Seconds 
FROM horario  
where id=11;

SELECT EXTRACT( HOUR   FROM CAST( hora_inicio AS TIMESTAMP ) ) AS Hours, 
       EXTRACT( MINUTE FROM CAST( hora_inicio AS TIMESTAMP ) ) AS Minutes, 
       EXTRACT( SECOND FROM CAST( hora_inicio AS TIMESTAMP ) ) AS Seconds 
FROM horario  
where id=12;

select creditos_teoricos, nombre_curso from curso 
where creditos_teoricos = (select min(creditos_teoricos) from cursos);

select creditos_teoricos, nombre_curso from curso 
where creditos_teoricos = (select min(creditos_teoricos) from curso);

select creditos_teoricos, nombre_curso from curso 
where creditos_teoricos = (select max(creditos_teoricos) from curso);

SELECT  
  CASE  
    WHEN hora_inicio < TO_DATE('14:00', 'HH24:MI') THEN 'Matutina'  
    WHEN hora_inicio < TO_DATE('18:00', 'HH24:MI') THEN 'Vespertina'  
    ELSE 'Nocturna'  
  END AS Jornada,  
  COUNT(*) AS Cantidad_Cursos 
FROM  
  Horario h  
  JOIN Asignacion a ON h.curso = a.id_curso  
WHERE  
  a.semestre = 4 
GROUP BY  
  CASE  
    WHEN hora_inicio < TO_DATE('14:00', 'HH24:MI') THEN 'Matutina'  
    WHEN hora_inicio < TO_DATE('18:00', 'HH24:MI') THEN 'Vespertina'  
    ELSE 'Nocturna'  
  END 
ORDER BY  
  Cantidad_Cursos DESC 
FETCH FIRST ROW ONLY;

select hora_inicio from horaio;

select hora_inicio as Timestamp from horario;

select hora_inicio as Timestamp from horario;

select hora_inicio from horario;

select hora_inicio as Timestamp from horario;

select (hora_inicio as Timestamp)as Hours from horario;

select (hora_inicio as Timestamp)as Hours from horario;

select EXTRACT( HOUR   FROM CAST( hora_inicio AS TIMESTAMP ) ) AS Hours  from horario;

SELECT  
  CASE  
    WHEN EXTRACT( HOUR   FROM CAST( hora_inicio AS TIMESTAMP ) ) AS Hours < TO_DATE('14:00', 'HH24:MI') THEN 'Matutina'  
    WHEN EXTRACT( HOUR   FROM CAST( hora_inicio AS TIMESTAMP ) ) AS Hours < TO_DATE('18:00', 'HH24:MI') THEN 'Vespertina'  
    ELSE 'Nocturna'  
  END AS Jornada,  
  COUNT(*) AS Cantidad_Cursos 
FROM  
  Horario h  
  JOIN Asignacion a ON h.curso = a.id_curso  
WHERE  
  a.semestre = 4 
GROUP BY  
  CASE  
    WHEN EXTRACT( HOUR   FROM CAST( hora_inicio AS TIMESTAMP ) ) AS Hours < TO_DATE('14:00', 'HH24:MI') THEN 'Matutina'  
    WHEN EXTRACT( HOUR   FROM CAST( hora_inicio AS TIMESTAMP ) ) AS Hours < TO_DATE('18:00', 'HH24:MI') THEN 'Vespertina'  
    ELSE 'Nocturna'  
  END 
ORDER BY  
  Cantidad_Cursos DESC 
FETCH FIRST ROW ONLY;

select count(prerrequisitos) from Curso;

select count(prerrequisitos) from Curso 
where prrerrequisito = 'Microeconomia';

select count(prerrequisitos) from Curso 
where prerrequisito = 'Microeconomia';

select count(prerrequisitos) from Curso 
where prerrequisitos = 'Microeconomia';

select count(prerrequisitos) from Curso 
where prerrequisitos = (select max(prerrequisitos) from curso);

SELECT  
  prerrequisitos, COUNT(*) AS Cantidad 
FROM  
  CURSO 
GROUP BY  
  prerrequisitos 
ORDER BY  
  Cantidad DESC 
FETCH FIRST ROW ONLY;

SELECT  
  prerrequisitos, COUNT(*) AS Cantidad 
FROM  
  CURSO 
 WHERE  
  prerrequisitos IS NOT NULL 
  AND prerrequisitos != 'N/A' 
GROUP BY  
  prerrequisitos 
ORDER BY  
  Cantidad DESC 
FETCH FIRST ROW ONLY;

SELECT  
  prerrequisitos, COUNT(*) AS Cantidad 
FROM  
  CURSO 
 WHERE  
  prerrequisitos IS NOT NULL 
  AND prerrequisitos != 'N/A' 
GROUP BY  
  prerrequisitos 
ORDER BY  
  Cantidad DESC 
FETCH FIRST ROW ONLY;

SELECT  
  * 
FROM  
  CURSO 
 WHERE  
  prerrequisitos IS NOT NULL 
  AND prerrequisitos != 'N/A' 
GROUP BY  
  prerrequisitos 
ORDER BY  
  Cantidad DESC 
FETCH FIRST ROW ONLY;

SELECT  
  *, COUNT(*) AS Cantidad 
FROM  
  CURSO 
 WHERE  
  prerrequisitos IS NOT NULL 
  AND prerrequisitos != 'N/A' 
GROUP BY  
  prerrequisitos 
ORDER BY  
  Cantidad DESC 
FETCH FIRST ROW ONLY;

SELECT  
  codigo_curso, nombre_curso, descripcion, creditos_teoricos, creditos_practicos, nbr_prerrequisitosprerrequisito, COUNT(*) AS Cantidad 
FROM  
  CURSO 
 WHERE  
  prerrequisitos IS NOT NULL 
  AND prerrequisitos != 'N/A' 
GROUP BY  
  prerrequisitos 
ORDER BY  
  Cantidad DESC 
FETCH FIRST ROW ONLY;

SELECT  
  codigo_curso, nombre_curso, descripcion, creditos_teoricos, creditos_practicos, nbr_prerrequisitos,prerrequisitos, COUNT(*) AS Cantidad 
FROM  
  CURSO 
 WHERE  
  prerrequisitos IS NOT NULL 
  AND prerrequisitos != 'N/A' 
GROUP BY  
  prerrequisitos 
ORDER BY  
  Cantidad DESC 
FETCH FIRST ROW ONLY;

SELECT  
  codigo_curso, nombre_curso, descripcion, creditos_teoricos, creditos_practicos, nbr_prerrequisitos,prerrequisitos, COUNT(*) AS Cantidad 
FROM  
  CURSO 
 WHERE  
  prerrequisitos IS NOT NULL 
  AND prerrequisitos != 'N/A' 
ORDER BY  
  Cantidad DESC 
FETCH FIRST ROW ONLY;

SELECT  
prerrequisitos, COUNT(*) AS Cantidad 
FROM  
  CURSO 
 WHERE  
  prerrequisitos IS NOT NULL 
  AND prerrequisitos != 'N/A' 
GROUP BY  
  prerrequisitos 
ORDER BY  
  Cantidad DESC 
FETCH FIRST ROW ONLY;

SELECT  
*, COUNT(*) AS Cantidad 
FROM  
  CURSO 
 WHERE  
  prerrequisitos IS NOT NULL 
  AND prerrequisitos != 'N/A' 
GROUP BY  
  prerrequisitos 
ORDER BY  
  Cantidad DESC 
FETCH FIRST ROW ONLY;

SELECT  
prerrequisitos, COUNT(*) AS Cantidad and * 
FROM  
  CURSO 
 WHERE  
  prerrequisitos IS NOT NULL 
  AND prerrequisitos != 'N/A' 
GROUP BY  
  prerrequisitos 
ORDER BY  
  Cantidad DESC 
FETCH FIRST ROW ONLY;

SELECT  
  CURSO.codigo_curso,  
  CURSO.nombre_curso,  
  CURSO.descripcion,  
  CURSO.creditos_teoricos,  
  CURSO.creditos_practicos,  
  CURSO.prerrequisitos,  
  COUNT(*) AS nbr_prerrequisitos 
FROM  
  CURSO  
  JOIN ( 
    SELECT  
      prerrequisitos, COUNT(*) AS Cantidad 
    FROM  
      CURSO 
    WHERE  
      prerrequisitos IS NOT NULL 
      AND prerrequisitos != 'N/A' 
    GROUP BY  
      prerrequisitos 
    ORDER BY  
      Cantidad DESC 
    FETCH FIRST ROW ONLY 
  ) AS subquery 
  ON CURSO.prerrequisitos = subquery.prerrequisitos 
GROUP BY  
  CURSO.codigo_curso,  
  CURSO.nombre_curso,  
  CURSO.descripcion,  
  CURSO.creditos_teoricos,  
  CURSO.creditos_practicos,  
  CURSO.prerrequisitos 
ORDER BY  
  nbr_prerrequisitos DESC 
FETCH FIRST ROW ONLY;

SELECT  
  codigo_curso, 
  nombre_curso, 
  descripcion, 
  creditos_teoricos, 
  creditos_practicos, 
  prerrequisitos, 
  COUNT(*) AS Cantidad 
FROM  
  CURSO 
WHERE  
  prerrequisitos IS NOT NULL 
  AND prerrequisitos != 'N/A' 
GROUP BY  
  codigo_curso, 
  nombre_curso, 
  descripcion, 
  creditos_teoricos, 
  creditos_practicos, 
  prerrequisitos 
ORDER BY  
  Cantidad DESC 
FETCH FIRST ROW ONLY;

SELECT  
  prerrequisitos, COUNT(*) AS Cantidad 
FROM  
  CURSO 
GROUP BY  
  prerrequisitos 
ORDER BY  
  Cantidad DESC 
FETCH FIRST ROW ONLY;

SELECT  
  prerrequisitos, COUNT(*) AS Cantidad 
FROM  
  CURSO 
GROUP BY  
  prerrequisitos 
    WHERE  
  prerrequisitos IS NOT NULL 
  AND prerrequisitos != 'N/A' 
ORDER BY  
  Cantidad DESC 
FETCH FIRST ROW ONLY;

SELECT  
  prerrequisitos, COUNT(*) AS Cantidad 
FROM  
  CURSO 
GROUP BY  
  prerrequisitos 
WHERE  
  prerrequisitos IS NOT NULL 
  AND prerrequisitos != 'N/A' 
ORDER BY  
  Cantidad DESC 
FETCH FIRST ROW ONLY;

SELECT  
  codigo_curso, 
  nombre_curso, 
  descripcion, 
  creditos_teoricos, 
  creditos_practicos, 
  prerrequisitos, 
  COUNT(*) AS Cantidad 
FROM  
  CURSO 
WHERE  
  prerrequisitos IS NOT NULL 
  AND prerrequisitos != 'N/A' 
GROUP BY  
  codigo_curso, 
  nombre_curso, 
  descripcion, 
  creditos_teoricos, 
  creditos_practicos, 
  prerrequisitos 
HAVING  
  COUNT(*) = ( 
    SELECT  
      MAX(CountPrerrequisitos) 
    FROM  
      ( 
        SELECT  
          prerrequisitos, COUNT(*) AS CountPrerrequisitos 
        FROM  
          CURSO 
        WHERE  
          prerrequisitos IS NOT NULL 
          AND prerrequisitos != 'N/A' 
        GROUP BY  
          prerrequisitos 
      ) AS subconsulta 
  ) 
FETCH FIRST ROW ONLY;

SELECT  
  prerrequisitos, COUNT(*) AS Cantidad 
FROM  
  CURSO 
GROUP BY  
  prerrequisitos 
WHERE  
prerrequisitos IS NOT NULL 
AND prerrequisitos != 'N/A' 
ORDER BY  
  Cantidad DESC 
FETCH FIRST ROW ONLY;

SELECT  
  prerrequisitos, COUNT(*) AS Cantidad 
FROM  
  CURSO 
    WHERE  
prerrequisitos IS NOT NULL 
AND prerrequisitos != 'N/A' 
GROUP BY  
  prerrequisitos 
 
ORDER BY  
  Cantidad DESC 
FETCH FIRST ROW ONLY;

SELECT  
  prerrequisitos, 
  codigo_curso, 
  nombre_curso, 
  descripcion, 
  creditos_teoricos, 
  creditos_practicos, COUNT(*) AS Cantidad 
FROM  
  CURSO 
    WHERE  
prerrequisitos IS NOT NULL 
AND prerrequisitos != 'N/A' 
GROUP BY  
  prerrequisitos, 
  codigo_curso, 
  nombre_curso, 
  descripcion, 
  creditos_teoricos, 
  creditos_practicos 
 
ORDER BY  
  Cantidad DESC 
FETCH FIRST ROW ONLY;

SELECT  
  prerrequisitos, 
  codigo_curso, 
  descripcion, 
  creditos_teoricos, 
  creditos_practicos, COUNT(*) AS Cantidad 
FROM  
  CURSO 
    WHERE  
prerrequisitos IS NOT NULL 
AND prerrequisitos != 'N/A' 
GROUP BY  
  prerrequisitos, 
  codigo_curso, 
  descripcion, 
  creditos_teoricos, 
  creditos_practicos 
ORDER BY  
  Cantidad DESC 
FETCH FIRST ROW ONLY;

SELECT  
  prerrequisitos, COUNT(*) AS Cantidad 
FROM  
  CURSO 
    WHERE  
prerrequisitos IS NOT NULL 
AND prerrequisitos != 'N/A' 
GROUP BY  
  prerrequisitos 
ORDER BY  
  Cantidad DESC 
FETCH FIRST ROW ONLY;

SELECT  
  prerrequisitos, COUNT(*) AS Cantidad 
FROM  
  CURSO 
    WHERE  
prerrequisitos IS NOT NULL 
AND prerrequisitos != 'N/A' 
GROUP BY  
  prerrequisitos 
FETCH FIRST ROW ONLY;

SELECT  
  prerrequisitos, COUNT(*) AS Cantidad 
FROM  
  CURSO 
    WHERE  
prerrequisitos IS NOT NULL 
AND prerrequisitos != 'N/A' 
GROUP BY  
  prerrequisitos 
 
FETCH FIRST ROW ONLY;

SELECT  
  prerrequisitos, COUNT(*) AS Cantidad 
FROM  
  CURSO 
    WHERE  
prerrequisitos IS NOT NULL 
AND prerrequisitos != 'N/A' 
GROUP BY  
  prerrequisitos 
ORDER BY  
  Cantidad DESC 
FETCH FIRST ROW ONLY;

SELECT  
  prerrequisitos, 
  codigo_curso, 
  descripcion, 
  creditos_teoricos, 
  creditos_practicos, COUNT(*) AS Cantidad 
FROM  
  CURSO 
    WHERE  
prerrequisitos IS NOT NULL 
AND prerrequisitos != 'N/A' 
GROUP BY  
  prerrequisitos, 
  codigo_curso, 
  descripcion, 
  creditos_teoricos, 
  creditos_practicos 
ORDER BY  
  Cantidad asc 
FETCH FIRST ROW ONLY;

SELECT  
  prerrequisitos, 
  codigo_curso, 
  nombre_curso, 
  descripcion, 
  creditos_teoricos, 
  creditos_practicos, COUNT(*) AS Cantidad 
FROM  
  CURSO 
    WHERE  
prerrequisitos IS NOT NULL 
AND prerrequisitos != 'N/A' 
GROUP BY  
  prerrequisitos, 
  codigo_curso, 
  nombre_curso, 
  descripcion, 
  creditos_teoricos, 
  creditos_practicos 
ORDER BY  
  Cantidad DESC;

SELECT  
  prerrequisitos, 
  codigo_curso, 
  nombre_curso, 
  descripcion, 
  creditos_teoricos, 
  creditos_practicos, COUNT(*) AS Cantidad 
FROM  
  CURSO 
    WHERE  
prerrequisitos IS NOT NULL 
AND prerrequisitos != 'N/A' 
GROUP BY  
  prerrequisitos, 
  codigo_curso, 
  nombre_curso, 
  descripcion, 
  creditos_teoricos, 
  creditos_practicos 
ORDER BY  
  Cantidad asc;

SELECT  
  prerrequisitos, 
  codigo_curso, 
  nombre_curso, 
  descripcion, 
  creditos_teoricos, 
  creditos_practicos, COUNT(*) AS Cantidad 
FROM  
  CURSO 
    WHERE  
prerrequisitos IS NOT NULL 
AND prerrequisitos != 'N/A' 
GROUP BY  
  prerrequisitos, 
  codigo_curso, 
  nombre_curso, 
  descripcion, 
  creditos_teoricos, 
  creditos_practicos 
ORDER BY  
  Cantidad DESC;

SELECT  
  prerrequisitos, 
  codigo_curso, 
  nombre_curso, 
  descripcion, 
  creditos_teoricos, 
  creditos_practicos, COUNT(*) AS Cantidad 
FROM  
  CURSO 
    WHERE  
prerrequisitos IS NOT NULL 
AND prerrequisitos != 'N/A' 
GROUP BY  
  prerrequisitos, 
  codigo_curso, 
  nombre_curso, 
  descripcion, 
  creditos_teoricos, 
  creditos_practicos 
ORDER BY  
  Cantidad DESC 
FETCH FIRST ROW ONLY;

SELECT  
  prerrequisitos, COUNT(*) AS Cantidad 
FROM  
  CURSO 
    WHERE  
prerrequisitos IS NOT NULL 
AND prerrequisitos != 'N/A' 
GROUP BY  
  prerrequisitos 
ORDER BY  
  Cantidad DESC 
FETCH FIRST ROW ONLY;

SELECT  
codigo_curso, 
  nombre_curso, 
  descripcion, 
  creditos_teoricos, 
  creditos_practicos and 
  prerrequisitos, COUNT(*) AS Cantidad 
FROM  
  CURSO 
    WHERE  
prerrequisitos IS NOT NULL 
AND prerrequisitos != 'N/A' 
GROUP BY  
  prerrequisitos 
ORDER BY  
  Cantidad DESC 
FETCH FIRST ROW ONLY;

SELECT  
codigo_curso, 
  nombre_curso, 
  descripcion, 
  creditos_teoricos, 
  creditos_practicos from curso and 
  prerrequisitos, COUNT(*) AS Cantidad 
FROM  
  CURSO 
    WHERE  
prerrequisitos IS NOT NULL 
AND prerrequisitos != 'N/A' 
GROUP BY  
  prerrequisitos,codigo_curso, 
  nombre_curso, 
  descripcion, 
  creditos_teoricos, 
  creditos_practicos 
ORDER BY  
  Cantidad DESC 
FETCH FIRST ROW ONLY;

SELECT  
codigo_curso, 
  nombre_curso, 
  descripcion, 
  creditos_teoricos, 
  creditos_practicos from curso and 
 select prerrequisitos, COUNT(*) AS Cantidad 
FROM  
  CURSO 
    WHERE  
prerrequisitos IS NOT NULL 
AND prerrequisitos != 'N/A' 
GROUP BY  
  prerrequisitos,codigo_curso, 
  nombre_curso, 
  descripcion, 
  creditos_teoricos, 
  creditos_practicos 
ORDER BY  
  Cantidad DESC 
FETCH FIRST ROW ONLY;

select * from asignacion;

select * from asignacion 
where semestre = 3 or semestre = 4;

select * from asignacion 
where semestre = 3 and semestre = 4;

select * from asignacion 
where semestre = 3 or semestre = 4;

SELECT  
  a.id_asignacion,  
  a.carne_alumno,  
  a.codigo_curso,  
  c.nombre_curso 
FROM  
  ASIGNACION a  
  JOIN CURSO c ON a.codigo_curso = c.codigo_curso;

SELECT  
  a.id,  
  a.carnet,  
  a.id_curso,  
  c.nombre_curso 
FROM  
  ASIGNACION a  
  JOIN CURSO c ON a.id_curso = c.codigo_curso;

SELECT  
  a.id,  
  a.id_curso,  
  c.nombre_curso 
FROM  
  ASIGNACION a  
  JOIN CURSO c ON a.id_curso = c.codigo_curso;

SELECT  
  a.id,  
  a.id_curso,  
  c.nombre_curso 
  a.semestre;

FROM  


  ASIGNACION a  


    where semestre =3 or semestre = 4; 


  JOIN CURSO c ON a.id_curso = c.codigo_curso;


SELECT  
  a.id,  
  a.id_curso,  
  c.nombre_curso 
  a.semestre;

FROM  


  ASIGNACION a  


    where a.semestre =3 or a.semestre = 4; 


  JOIN CURSO c ON a.id_curso = c.codigo_curso;


SELECT  
  a.id,  
  a.id_curso,  
  c.nombre_curso 
  a.semestre;

FROM  


  ASIGNACION a  


  JOIN CURSO c ON a.id_curso = c.codigo_curso;


SELECT  
  a.id,  
  a.id_curso,  
  c.nombre_curso 
 
FROM  
  ASIGNACION a  
  JOIN CURSO c ON a.id_curso = c.codigo_curso;

SELECT  
  a.id,  
  a.id_curso,  
  c.nombre_curso, 
  a.semestre 
 
FROM  
  ASIGNACION a  
  where semestre =3 or semestre =4;

  JOIN CURSO c ON a.id_curso = c.codigo_curso;


SELECT  
  a.id,  
  a.id_curso,  
  c.nombre_curso, 
  a.semestre 
 
FROM  
  ASIGNACION a  
   
  JOIN CURSO c ON a.id_curso = c.codigo_curso 
where semestre =3 or semestre =4;

SELECT  
  a.id,  
  a.id_curso,  
  c.nombre_curso, 
  a.semestre, 
  a.nota_curso 
 
FROM  
  ASIGNACION a  
   
  JOIN CURSO c ON a.id_curso = c.codigo_curso 
where semestre =3 or semestre =4;

SELECT  
  a.id,  
  a.id_curso,  
  c.nombre_curso, 
  a.semestre, 
  a.nota_curso, 
  a.id_estudiante 
FROM  
  ASIGNACION a  
   
  JOIN CURSO c ON a.id_curso = c.codigo_curso 
where semestre =4;

select * from asignacion 
where semetre = 4;

select * from asignacion 
where semestre = 4;

SELECT  
  a.id,  
  a.id_curso,  
  c.nombre_curso, 
  a.semestre, 
  a.nota_curso, 
  a.id_estudiante 
FROM  
  ASIGNACION a  
   
  JOIN CURSO c ON a.id_curso = c.codigo_curso 
where semestre =4;

update asignacion set nota_curso = 70 where id_curso =53;

SELECT  
  a.id,  
  a.id_curso,  
  c.nombre_curso, 
  a.semestre, 
  a.nota_curso, 
  a.id_estudiante 
FROM  
  ASIGNACION a  
   
  JOIN CURSO c ON a.id_curso = c.codigo_curso 
where semestre =4;

select * from asignacion 
where semestre = 4;

SELECT  
  a.id,  
  a.id_curso,  
  c.nombre_curso, 
  a.semestre, 
  a.nota_curso, 
  a.id_estudiante 
FROM  
  ASIGNACION a  
   
  JOIN CURSO c ON a.id_curso = c.codigo_curso 
where semestre =4;

update asignacion set nota_curso = 83 where id_curso =62;

SELECT  
  a.id,  
  a.id_curso,  
  c.nombre_curso, 
  a.semestre, 
  a.nota_curso, 
  a.id_estudiante 
FROM  
  ASIGNACION a  
   
  JOIN CURSO c ON a.id_curso = c.codigo_curso 
where semestre =4;

update asignacion set nota_curso = 69 where id_curso =63;

update asignacion set nota_curso = 78 where id_curso =64;

SELECT  
  a.id,  
  a.id_curso,  
  c.nombre_curso, 
  a.semestre, 
  a.nota_curso, 
  a.id_estudiante 
FROM  
  ASIGNACION a  
   
  JOIN CURSO c ON a.id_curso = c.codigo_curso 
where semestre =4;

update asignacion set nota_curso = 93 where id_curso =66;

update asignacion set nota_curso = 89 where id_curso =65;

update asignacion set nota_curso = 80 where id_curso =67;

SELECT  
  a.id,  
  a.id_curso,  
  c.nombre_curso, 
  a.semestre, 
  a.nota_curso, 
  a.id_estudiante 
FROM  
  ASIGNACION a  
   
  JOIN CURSO c ON a.id_curso = c.codigo_curso 
where semestre =4;

SELECT AVG(nota) AS Promedio 
FROM NOTA 
WHERE carne IN ('20210030', '20210003', '20210104') AND codigo_seccion IN ( 
  SELECT codigo_seccion  
  FROM SECCION  
  WHERE codigo_curso IN ( 
    SELECT codigo_curso  
    FROM CURSO  
    WHERE semestre = 4 
  ) 
);

SELECT AVG(nota_curso) AS Promedio 
FROM asignacion 
WHERE carnet IN ('20210030', '20210003', '20210104')  
  WHERE codigo_curso IN ( 
    SELECT codigo_curso  
    FROM CURSO  
    WHERE semestre = 4);

SELECT AVG(nota_curso) AS Promedio 
FROM asignacion 
WHERE carnet IN ('20210030', '20210003', '20210104') AND codigo_seccion IN ( 
  SELECT codigo_seccion  
  FROM SECCION  
  WHERE codigo_curso IN ( 
    SELECT codigo_curso  
    FROM CURSO  
    WHERE semestre = 4 
  ) 
);

SELECT AVG(nota_curso) AS Promedio 
FROM asignacion 
WHERE carnet IN ('20210030', '20210003', '20210104')  
    SELECT codigo_curso  
    FROM CURSO  
    WHERE semestre = 4;

SELECT AVG(nota_curso) AS Promedio 
FROM asignacion 
WHERE carnet IN ('20210030', '20210003', '20210104') AND codigo_seccion IN ( 
  SELECT codigo_seccion  
  FROM SECCION  
  WHERE codigo_curso IN ( 
    SELECT codigo_curso  
    FROM CURSO  
    WHERE semestre = 4 
  ) 
);

SELECT AVG(nota_curso) AS Promedio 
FROM asignacion 
WHERE carnet IN ('20210030', '20210003', '20210104') AND codigo_curso IN ( 
  SELECT codigo_curso  
  FROM asignaciones  
  WHERE codigo_curso IN ( 
    SELECT codigo_curso  
    FROM CURSO  
    WHERE semestre = 4 
  ) 
);

SELECT AVG(nota_curso) AS Promedio 
FROM asignacion 
WHERE carnet IN ('20210030', '20210003', '20210104') AND id_curso IN ( 
  SELECT id_curso  
  FROM asignaciones  
  WHERE id_curso IN ( 
    SELECT id_curso  
    FROM CURSO  
    WHERE semestre = 4 
  ) 
);

SELECT AVG(nota_curso) AS Promedio 
FROM asignacion 
WHERE id_estudiante IN ('20210030', '20210003', '20210104') AND id_curso IN ( 
  SELECT id_curso  
  FROM asignaciones  
  WHERE id_curso IN ( 
    SELECT id_curso  
    FROM CURSO  
    WHERE semestre = 4 
  ) 
);

SELECT AVG(nota_curso) AS Promedio 
FROM asignacion 
WHERE id_estudiante IN ('20210030', '20210003', '20210104') AND id_curso IN ( 
  SELECT id_curso  
  FROM asignacion  
  WHERE id_curso IN ( 
    SELECT id_curso  
    FROM CURSO  
    WHERE semestre = 4 
  ) 
);

SELECT id_estudiante, AVG(nota_curso) AS Promedio 
FROM asignacion 
WHERE id_estudiante IN ('20210030', '20210003', '20210104') AND id_curso IN ( 
  SELECT id_curso  
  FROM asignacion  
  WHERE id_curso IN ( 
    SELECT id_curso  
    FROM CURSO  
    WHERE semestre = 4 
  ) 
) 
GROUP BY id_estudiante;

SELECT  
  a.id,  
  a.id_curso,  
  c.nombre_curso, 
  a.semestre, 
  a.nota_curso, 
  a.id_estudiante 
FROM  
  ASIGNACION a  
   
  JOIN CURSO c ON a.id_curso = c.codigo_curso 
where semestre =4;

SELECT id_estudiante, AVG(nota_curso) AS Promedio 
FROM asignacion 
WHERE id_estudiante IN ('20210030', '20210003', '20210104') AND id_curso IN ( 
  SELECT id_curso  
  FROM asignacion  
  WHERE id_curso IN ( 
    SELECT id_curso  
    FROM CURSO  
    WHERE semestre = 4 
  ) 
) 
GROUP BY id_estudiante;

SELECT c.nombre_curso,  
       AVG(a.nota_curso) AS promedio,  
       MAX(a.nota_curso) AS mayor_nota  
FROM curso c  
JOIN asignacion a ON c.id_curso = a.id_curso  
WHERE a.nota_curso >= 60  
  AND c.semestre IN (3, 4)  
GROUP BY c.id_curso, c.nombre_curso  
HAVING AVG(a.nota_curso) = ( 
  SELECT MAX(avg_nota)  
  FROM ( 
    SELECT AVG(nota_curso) AS avg_nota  
    FROM curso  
    JOIN asignacion ON curso.id_curso = asignacion.id_curso  
    WHERE nota_curso >= 60  
      AND semestre IN (3, 4)  
    GROUP BY id_curso 
  ) t 
);

SELECT c.nombre_curso,  
       AVG(a.nota_curso) AS promedio,  
       MAX(a.nota_curso) AS mayor_nota  
FROM curso c  
JOIN asignacion a ON c.codigo_curso = a.id_curso  
WHERE a.nota_curso >= 60  
  AND a.semestre IN (3, 4)  
GROUP BY c.codigo_curso, c.nombre_curso  
HAVING AVG(a.nota_curso) = ( 
  SELECT MAX(avg_nota)  
  FROM ( 
    SELECT AVG(nota_curso) AS avg_nota  
    FROM curso  
    JOIN asignacion ON curso.codigo_curso = asignacion.id_curso  
    WHERE nota_curso >= 60  
      AND semestre IN (3, 4)  
    GROUP BY codigo_curso 
  ) t 
);

SELECT c.nombre_curso,  
       AVG(a.nota_curso) AS promedio,  
       MAX(a.nota_curso) AS mayor_nota  
FROM curso c  
JOIN asignacion a ON c.codigo_curso = a.id_curso  
WHERE a.nota_curso >= 60  
  AND a.semestre IN (3, 4)  
GROUP BY c.codigo_curso, c.nombre_curso  
HAVING AVG(a.nota_curso) = ( 
  SELECT MAX(avg_nota)  
  FROM ( 
    SELECT AVG(nota_curso) AS avg_nota  
    FROM curso  
    JOIN asignacion ON curso.codigo_curso = asignacion.id_curso  
    WHERE nota_curso >= 60  
      AND semestre IN (3, 4)  
    GROUP BY codigo_curso 
  )  
);

select * from asignaciones where nombre_curso = 'Automation Testing';

select * from asignacion where nombre_curso = 'Automation Testing';

select * from curso where nombre_curso = 'Automation Testing';

select * from asignacion where id_curso = 66;

update asignacion 
set nota_curso = 90 
where id = 200 ;

update asignacion 
set nota_curso = 94 
where id = 199 ;

select * from asignacion where id_curso = 66;

update asignacion 
set nota_curso = 90 
where id = 200 ;

select * from asignacion where id_curso = 66;

SELECT c.nombre_curso,  
       AVG(a.nota_curso) AS promedio,  
       MAX(a.nota_curso) AS mayor_nota  
FROM curso c  
JOIN asignacion a ON c.codigo_curso = a.id_curso  
WHERE a.nota_curso >= 60  
  AND a.semestre IN (3, 4)  
GROUP BY c.codigo_curso, c.nombre_curso  
HAVING AVG(a.nota_curso) = ( 
  SELECT MAX(avg_nota)  
  FROM ( 
    SELECT AVG(nota_curso) AS avg_nota  
    FROM curso  
    JOIN asignacion ON curso.codigo_curso = asignacion.id_curso  
    WHERE nota_curso >= 60  
      AND semestre IN (3, 4)  
    GROUP BY codigo_curso 
  )  
);

SELECT  
  edificio, COUNT(*) AS Cantidad 
FROM  
  horario 
GROUP BY  
  edificio 
ORDER BY  
  Cantidad DESC 
FETCH FIRST ROW ONLY;

SELECT SUM(asignacion.creditos_practicos) AS total_creditos_practicos 
FROM asignacion 
INNER JOIN curso ON asignacion.id_curso = curso.codigo_curso 
WHERE asignacion.semestre = 3;

SELECT SUM(curso.creditos_practicos) AS total_creditos_practicos 
FROM curso 
INNER JOIN curso ON asignacion.id_curso = curso.codigo_curso 
WHERE asignacion.semestre = 3;

SELECT SUM(curso.creditos_practicos) AS total_creditos_practicos 
FROM curso 
INNER JOIN asignacion ON asignacion.id_curso = curso.codigo_curso 
WHERE asignacion.semestre = 3;

insert into impartir_curso (nombre_catedratico, apellido_catedratico, seccion_curso, cantidad_ciclo) 
Values('Luis Angel', 'Tortola', '1', 3);

